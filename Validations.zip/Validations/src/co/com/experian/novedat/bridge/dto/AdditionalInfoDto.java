package co.com.experian.novedat.bridge.dto;

import lombok.Data;

@Data
public class AdditionalInfoDto {
    private String admisionDate;
    private String lastUpdateDate;
    private String datePortfolioUpdate;
    private String caseNumber;
    private String subscriberName; //Nombre del suscriptor que reporta la cuenta.
    private Long idGroup;
    private String comments;
}
