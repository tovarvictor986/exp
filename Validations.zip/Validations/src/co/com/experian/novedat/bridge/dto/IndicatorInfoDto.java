package co.com.experian.novedat.bridge.dto;

import lombok.Data;

@Data
public class IndicatorInfoDto {

    private Integer typeOfBlockInd;
    private Integer accountOpeningDateInd;
    private Integer eventInd;
    private Integer novedatStateDateInd;
    private Integer accountAdjectiveInd;
    private Integer dateAdjectiveInd;
    private Integer disputeIndicatorInd;
    private Integer ratingInd;
    private Integer stateOfAccountHolderInd;
    private Integer fillingOfficeInd;
    private Integer fillingCityInd;
    private Integer daneCitySettlementCodeInd;
    private Integer currencyTypeInd;
    private Integer adjective2Ind;

    //Informacion para cuenta corriente
    private Integer impoundInd;
    private Integer impoundDateInd;
    private Integer numberOfChecksReturnedInd;
    private Integer numberOfChecksReturnedIndicatorInd;
    private Integer overdraftIndicatorInd;
    private Integer authorizedOverdraftCreditLimitInd;
    private Integer authorizedOverdraftDaysInd;
    private Integer reportDateOverdraftDateInd;
    private Integer accountCategoryInd;

    //Informacion oara la trama de cartera
    private Integer expiryDateInd;
    private Integer feeValueInd;
    private Integer frequentBehaviour1Ind;
    private Integer accountAdjectiveInd2;
    private Integer dateAdjectiveInd2;
    private Integer accountAdjectiveInd3;
    private Integer dateAdjectiveInd3;
    private Integer initialValueInd;
    private Integer debtBalanceInd;
    private Integer valueBalanceOverdueInd;
    private Integer typeOfCreditInd;
    private Integer feeChecksReturnedInd;
    private Integer totalValueOfChecksReturnedInd;
    private Integer totalValueOfChecksPaidInd;
    private Integer situationDateInd;
    private Integer frequentBehaviour2Ind;
    private Integer periodicityOfPayments;
    private Integer typeOfDebtorInd;
    private Integer paymentTypeInd;
    private Integer frequentBehaviour3Ind;
    private Integer frequentBehaviour4Ind;
    private Integer overdueDayInd;
    private Integer accountStatusInd;
    private Integer originStatusOfAccountInd;
    private Integer dateOfOriginStatusInd;
    private Integer paymentDeadlineInd;
    private Integer paymentDateInd;
    private Integer probabilityOfDefaultInd;
    private Integer privateBrandNameInd;
    private Integer cardClassInd;
    private Integer franchiseInd;
    private Integer cardStatusInd;
    private Integer dateOfCardStatusInd;
    private Integer permanenceClauseInd;
    private Integer contractTypeInd;
    private Integer permanenceClauseDateInd;
    private Integer guaranteeTypeInd;
}
