package co.com.experian.novedat.bridge.dto;

import lombok.Data;

import java.util.List;

@Data
public class ObligationInfoDto {
    public String event;//ICMCHK.NOV-REPORT-ABD06
    public String accountType;
    public String parameterizedAccountType;
    public String impound;    //Número de Embargo
    public String adjective="#####"; //ADJETIVO1-ABD07
    public String adjective2; //ADJETIVO2-ABD07
    public String adjective3; //ADJETIVO3-ABD07
    public String parameterizedAdjective;
    public String fillingOffice;     //oficina de radicacion NOMOFI-OFICINA /OFICINA-RADICACION-ICMVLR
    public String statusOwner;     //19 situacionEstadoTitular  *******
    public String parameterizedStatusOwner;
    public String currencyType;
    public String parameterizedCurrencyType;
    public String dateOfAccountStatus; //ICMCRE.FECHA-ESTADO-OBLIG-ABD07
    public String eventDate;     //Fecha Novedat
    public String accountOpeningDate; //ICMCHK.FECHA-APERT-ABD06 / ICMCRE.FECHA-APERTURA-ABD07
    public String feeValue; //ICMCRE.CUANTIA-ABD07
    public String stateOfAccountHolder; //ICMCRE.SITUACION-TITULAR-ABD07
    public String impoundDate; //Fecha que indica el último embargo de la cuenta.
    public String adjectiveDate; //FECHA-ADJETIVO1-ABD07
    public String adjectiveDate2; //FECHA-ADJETIVO2-ABD07 / ICMCRE.FEC-MAY-ADJ-ABD07
    public String adjectiveDate3; //FECHA-ADJETIVO3-ABD07
    public String fillingCityName; //M-CIUDAD-RADICACION-VLR-MOD / NOMCIU-OFICINA / CIUDAD-RADICACION-ICMVLR
    public String daneCitySettlementCode;     //Codigo Dane
    public String rating; //M-CALIFICACION-CHK-MOD / ICMCRE.CALIFICACIONM-ABD07
    public String numberOfChecksReturned;     //Cantidad de cheques devueltos
    public String overdraftIndicator;     //Indicador de sobregiro
    public String authorizedOverdraftCreditLimit; //Valor del cupo del sobregiro de la cuenta en miles de pesos
    public String authorizedOverdraftDays;     //Dias de sobregiros
    public String reportDateOverdraftDate; //Fecha en la que se reporta el cupo y/o días de sobregiro autorizado.
    public String accountCategory; //Clase de Cuentas (ver APOYO.CLASE_CTA_CTE de DataCAS)
    public String eventDate2; //Fecha Novedat dos duplicado en la trama detalle
    public String parameterizedCity;
    public String parameterizedEvent;
    public String feeValueInd; //ICMCRE.CUANTIA-ABD07
    public String initialValue;//VALOR-INICIAL-ABD07
    public String debtBalance; //ICMCRE.VALOR-SALDO-DEUDAM-ABD07  //************POR VALIDAR CAMPO
    public String valueBalanceOverdue; //ICMCRE.VALOR-SALDO-MORAM-ABD07 //************POR VALIDAR CAMPO
    public String typeOfCreditInd;  //ICMCRE.TIPO-OBLIGACION-ABD07
    public String totalValueOfChecksReturned; //ICMCRE.CUOTAS-CANCELADAS-ABD07
    public String totalValueOfChecksPaid; //ICMCRE.TOTAL-CUOTAS-ABD07
    public String situationDate; //ICMCRE.FECHA-SITUACION-ABD07 //************POR VALIDAR CAMPO  No esta en el XPM
    public String periodicityOfPayments; //ICMCRE.PERIODICIDAD-PAGO-ABD07
    public String typeOfDebtor;  //ICMCRE.GARANTE-ABD07
    public String paymentType;//ICMCRE.FORMA-PAGO-TOTAL-ABD07
    public String accountStatus; //ICMCRE.ESTADO-OBLIG-ABD07
    public String originStatusOfAccount;  //ICMCRE.ESTADO-ORIGEN-ABD07
    public String dateOfOriginStatus; //ICMCRE.FECHA-ESTADO-ORIGEN-ABD07
    public String paymentDeadline; //ICMCRE.FECHA-LIMITE-PAGO-ABD07
    public String paymentDate;//ICMCRE.FECHA-DE-PAGO-ABD07
    public String probabilityOfDefault; //ICMCRE.PROBAB-INCUMP-ABD07
    public String privateBrandName; //ICMCRE.TARJ-MARCA-PRIV-ABD07
    public String cardClass;     //ICMCRE.TARJ-CLASE-ABD07
    public String franchise;  //ICMCRE.TARJ-FRANQUICIA-ABD07
    public String cardStatus;     //ICMCRE.TARJ-ESTADO-PLAST-ABD07
    public String dateOfCardStatus;  //ICMCRE.TARJ-FEC-ESTADO-PLAST-ABD07
    public String permanenceClause;   //ICMCRE.REAL-CLAUS-PERM-ABD07
    public String contractType;    //ICMCRE.REAL-TERMINO-CONTRATO-ABD07
    public String permanenceClauseDate;  //ICMCRE.REAL-FEC-CLAUS-PERM-ABD07
    public String guaranteeType;     //ICMCRE.TIPO-GARANTIA-ABD07

    //Informacion adicional de campos
    public String typeOfBlock; //ICMCHK.IND-BimpoundLOQUEO-ABD06 /ICMCRE.IND-BLOQUEO-ABD07
    public String frequentBehaviour1; //VECTOR-HIS-1-ABD07
    public String frequentBehaviour2; //ICMCRE.VECTOR-2-ABD07
    public String frequentBehaviour3;  //VECTOR-HIS-3-ABD07
    public String frequentBehaviour4; //VECTOR-HIS-4-ABD07
    public String disputeIndicator; //ICMCHK.IND-RECLAMO-ABD06 / ICMCRE.IND-RECLAMO-ABD07
    public String overdueDay; //ICMCRE.MOROSIDAD-ABD07*/

    public String numberOfChecksReturnedIndicator;//Indicador de cheques devueltos
    public String expiryDate; //ICMCRE.FECHA-VENCIMIENTO-ABD07

    /*CAMPOS NUEVOS UTILIZADOS EN LA INTERFAZ*/
    public String reportDateEvent;
    public String availableBalance;
    public String installmentsOverdue;
    public String paymentDeadLine;
    public String mortgageSubsidy;
    public String mortgageSubsidyDate;
    public String probablyOfDefault;
    public String totalCashDebit;
    public String totalCashCredit;
    public String totalDebitTransfer;
    public String totalCreditTransfer;
    public String numberCheckPaid;
    public String totalValueCheckReturned;
    public String totalValueCheckPaid;
    public String residenceCity;
    public String daneCityResidenceCode;
    public String residenceDepartment;
    public String residenceAddress;
    public String residencePhone;
    public String daneCityWorkCode;
    public String workCity;
    public String workDepartment;
    public String workAddress;
    public String workPhone;
    public String daneCityCorrespondenceCode;
    public String correspondenceCity;
    public String correspondenceDepartment;
    public String correspondenceAddress;
    public String email;
    public String cardNumber;
    public String city;
    public String scoreValue;
    public String originOfStatusAccount;
    public String guaranteeDetail;
    public String typeOfCredit;

    //public List<FrecuentBehaviorDto> frecuentBehavior;
    public String lastYear;
    public String lastMonth;
    public String initialYear;
    public String initialMonth;
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getParameterizedAccountType() {
		return parameterizedAccountType;
	}
	public void setParameterizedAccountType(String parameterizedAccountType) {
		this.parameterizedAccountType = parameterizedAccountType;
	}
	public String getImpound() {
		return impound;
	}
	public void setImpound(String impound) {
		this.impound = impound;
	}
	public String getAdjective() {
		return adjective;
	}
	public void setAdjective(String adjective) {
		this.adjective = adjective;
	}
	public String getAdjective2() {
		return adjective2;
	}
	public void setAdjective2(String adjective2) {
		this.adjective2 = adjective2;
	}
	public String getAdjective3() {
		return adjective3;
	}
	public void setAdjective3(String adjective3) {
		this.adjective3 = adjective3;
	}
	public String getParameterizedAdjective() {
		return parameterizedAdjective;
	}
	public void setParameterizedAdjective(String parameterizedAdjective) {
		this.parameterizedAdjective = parameterizedAdjective;
	}
	public String getFillingOffice() {
		return fillingOffice;
	}
	public void setFillingOffice(String fillingOffice) {
		this.fillingOffice = fillingOffice;
	}
	public String getStatusOwner() {
		return statusOwner;
	}
	public void setStatusOwner(String statusOwner) {
		this.statusOwner = statusOwner;
	}
	public String getParameterizedStatusOwner() {
		return parameterizedStatusOwner;
	}
	public void setParameterizedStatusOwner(String parameterizedStatusOwner) {
		this.parameterizedStatusOwner = parameterizedStatusOwner;
	}
	public String getCurrencyType() {
		return currencyType;
	}
	public void setCurrencyType(String currencyType) {
		this.currencyType = currencyType;
	}
	public String getParameterizedCurrencyType() {
		return parameterizedCurrencyType;
	}
	public void setParameterizedCurrencyType(String parameterizedCurrencyType) {
		this.parameterizedCurrencyType = parameterizedCurrencyType;
	}
	public String getDateOfAccountStatus() {
		return dateOfAccountStatus;
	}
	public void setDateOfAccountStatus(String dateOfAccountStatus) {
		this.dateOfAccountStatus = dateOfAccountStatus;
	}
	public String getEventDate() {
		return eventDate;
	}
	public void setEventDate(String eventDate) {
		this.eventDate = eventDate;
	}
	public String getAccountOpeningDate() {
		return accountOpeningDate;
	}
	public void setAccountOpeningDate(String accountOpeningDate) {
		this.accountOpeningDate = accountOpeningDate;
	}
	public String getFeeValue() {
		return feeValue;
	}
	public void setFeeValue(String feeValue) {
		this.feeValue = feeValue;
	}
	public String getStateOfAccountHolder() {
		return stateOfAccountHolder;
	}
	public void setStateOfAccountHolder(String stateOfAccountHolder) {
		this.stateOfAccountHolder = stateOfAccountHolder;
	}
	public String getImpoundDate() {
		return impoundDate;
	}
	public void setImpoundDate(String impoundDate) {
		this.impoundDate = impoundDate;
	}
	public String getAdjectiveDate() {
		return adjectiveDate;
	}
	public void setAdjectiveDate(String adjectiveDate) {
		this.adjectiveDate = adjectiveDate;
	}
	public String getAdjectiveDate2() {
		return adjectiveDate2;
	}
	public void setAdjectiveDate2(String adjectiveDate2) {
		this.adjectiveDate2 = adjectiveDate2;
	}
	public String getAdjectiveDate3() {
		return adjectiveDate3;
	}
	public void setAdjectiveDate3(String adjectiveDate3) {
		this.adjectiveDate3 = adjectiveDate3;
	}
	public String getFillingCityName() {
		return fillingCityName;
	}
	public void setFillingCityName(String fillingCityName) {
		this.fillingCityName = fillingCityName;
	}
	public String getDaneCitySettlementCode() {
		return daneCitySettlementCode;
	}
	public void setDaneCitySettlementCode(String daneCitySettlementCode) {
		this.daneCitySettlementCode = daneCitySettlementCode;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getNumberOfChecksReturned() {
		return numberOfChecksReturned;
	}
	public void setNumberOfChecksReturned(String numberOfChecksReturned) {
		this.numberOfChecksReturned = numberOfChecksReturned;
	}
	public String getOverdraftIndicator() {
		return overdraftIndicator;
	}
	public void setOverdraftIndicator(String overdraftIndicator) {
		this.overdraftIndicator = overdraftIndicator;
	}
	public String getAuthorizedOverdraftCreditLimit() {
		return authorizedOverdraftCreditLimit;
	}
	public void setAuthorizedOverdraftCreditLimit(
			String authorizedOverdraftCreditLimit) {
		this.authorizedOverdraftCreditLimit = authorizedOverdraftCreditLimit;
	}
	public String getAuthorizedOverdraftDays() {
		return authorizedOverdraftDays;
	}
	public void setAuthorizedOverdraftDays(String authorizedOverdraftDays) {
		this.authorizedOverdraftDays = authorizedOverdraftDays;
	}
	public String getReportDateOverdraftDate() {
		return reportDateOverdraftDate;
	}
	public void setReportDateOverdraftDate(String reportDateOverdraftDate) {
		this.reportDateOverdraftDate = reportDateOverdraftDate;
	}
	public String getAccountCategory() {
		return accountCategory;
	}
	public void setAccountCategory(String accountCategory) {
		this.accountCategory = accountCategory;
	}
	public String getEventDate2() {
		return eventDate2;
	}
	public void setEventDate2(String eventDate2) {
		this.eventDate2 = eventDate2;
	}
	public String getParameterizedCity() {
		return parameterizedCity;
	}
	public void setParameterizedCity(String parameterizedCity) {
		this.parameterizedCity = parameterizedCity;
	}
	public String getParameterizedEvent() {
		return parameterizedEvent;
	}
	public void setParameterizedEvent(String parameterizedEvent) {
		this.parameterizedEvent = parameterizedEvent;
	}
	public String getFeeValueInd() {
		return feeValueInd;
	}
	public void setFeeValueInd(String feeValueInd) {
		this.feeValueInd = feeValueInd;
	}
	public String getInitialValue() {
		return initialValue;
	}
	public void setInitialValue(String initialValue) {
		this.initialValue = initialValue;
	}
	public String getDebtBalance() {
		return debtBalance;
	}
	public void setDebtBalance(String debtBalance) {
		this.debtBalance = debtBalance;
	}
	public String getValueBalanceOverdue() {
		return valueBalanceOverdue;
	}
	public void setValueBalanceOverdue(String valueBalanceOverdue) {
		this.valueBalanceOverdue = valueBalanceOverdue;
	}
	public String getTypeOfCreditInd() {
		return typeOfCreditInd;
	}
	public void setTypeOfCreditInd(String typeOfCreditInd) {
		this.typeOfCreditInd = typeOfCreditInd;
	}
	public String getTotalValueOfChecksReturned() {
		return totalValueOfChecksReturned;
	}
	public void setTotalValueOfChecksReturned(String totalValueOfChecksReturned) {
		this.totalValueOfChecksReturned = totalValueOfChecksReturned;
	}
	public String getTotalValueOfChecksPaid() {
		return totalValueOfChecksPaid;
	}
	public void setTotalValueOfChecksPaid(String totalValueOfChecksPaid) {
		this.totalValueOfChecksPaid = totalValueOfChecksPaid;
	}
	public String getSituationDate() {
		return situationDate;
	}
	public void setSituationDate(String situationDate) {
		this.situationDate = situationDate;
	}
	public String getPeriodicityOfPayments() {
		return periodicityOfPayments;
	}
	public void setPeriodicityOfPayments(String periodicityOfPayments) {
		this.periodicityOfPayments = periodicityOfPayments;
	}
	public String getTypeOfDebtor() {
		return typeOfDebtor;
	}
	public void setTypeOfDebtor(String typeOfDebtor) {
		this.typeOfDebtor = typeOfDebtor;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getOriginStatusOfAccount() {
		return originStatusOfAccount;
	}
	public void setOriginStatusOfAccount(String originStatusOfAccount) {
		this.originStatusOfAccount = originStatusOfAccount;
	}
	public String getDateOfOriginStatus() {
		return dateOfOriginStatus;
	}
	public void setDateOfOriginStatus(String dateOfOriginStatus) {
		this.dateOfOriginStatus = dateOfOriginStatus;
	}
	public String getPaymentDeadline() {
		return paymentDeadline;
	}
	public void setPaymentDeadline(String paymentDeadline) {
		this.paymentDeadline = paymentDeadline;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getProbabilityOfDefault() {
		return probabilityOfDefault;
	}
	public void setProbabilityOfDefault(String probabilityOfDefault) {
		this.probabilityOfDefault = probabilityOfDefault;
	}
	public String getPrivateBrandName() {
		return privateBrandName;
	}
	public void setPrivateBrandName(String privateBrandName) {
		this.privateBrandName = privateBrandName;
	}
	public String getCardClass() {
		return cardClass;
	}
	public void setCardClass(String cardClass) {
		this.cardClass = cardClass;
	}
	public String getFranchise() {
		return franchise;
	}
	public void setFranchise(String franchise) {
		this.franchise = franchise;
	}
	public String getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(String cardStatus) {
		this.cardStatus = cardStatus;
	}
	public String getDateOfCardStatus() {
		return dateOfCardStatus;
	}
	public void setDateOfCardStatus(String dateOfCardStatus) {
		this.dateOfCardStatus = dateOfCardStatus;
	}
	public String getPermanenceClause() {
		return permanenceClause;
	}
	public void setPermanenceClause(String permanenceClause) {
		this.permanenceClause = permanenceClause;
	}
	public String getContractType() {
		return contractType;
	}
	public void setContractType(String contractType) {
		this.contractType = contractType;
	}
	public String getPermanenceClauseDate() {
		return permanenceClauseDate;
	}
	public void setPermanenceClauseDate(String permanenceClauseDate) {
		this.permanenceClauseDate = permanenceClauseDate;
	}
	public String getGuaranteeType() {
		return guaranteeType;
	}
	public void setGuaranteeType(String guaranteeType) {
		this.guaranteeType = guaranteeType;
	}
	public String getTypeOfBlock() {
		return typeOfBlock;
	}
	public void setTypeOfBlock(String typeOfBlock) {
		this.typeOfBlock = typeOfBlock;
	}
	public String getFrequentBehaviour1() {
		return frequentBehaviour1;
	}
	public void setFrequentBehaviour1(String frequentBehaviour1) {
		this.frequentBehaviour1 = frequentBehaviour1;
	}
	public String getFrequentBehaviour2() {
		return frequentBehaviour2;
	}
	public void setFrequentBehaviour2(String frequentBehaviour2) {
		this.frequentBehaviour2 = frequentBehaviour2;
	}
	public String getFrequentBehaviour3() {
		return frequentBehaviour3;
	}
	public void setFrequentBehaviour3(String frequentBehaviour3) {
		this.frequentBehaviour3 = frequentBehaviour3;
	}
	public String getFrequentBehaviour4() {
		return frequentBehaviour4;
	}
	public void setFrequentBehaviour4(String frequentBehaviour4) {
		this.frequentBehaviour4 = frequentBehaviour4;
	}
	public String getDisputeIndicator() {
		return disputeIndicator;
	}
	public void setDisputeIndicator(String disputeIndicator) {
		this.disputeIndicator = disputeIndicator;
	}
	public String getOverdueDay() {
		return overdueDay;
	}
	public void setOverdueDay(String overdueDay) {
		this.overdueDay = overdueDay;
	}
	public String getNumberOfChecksReturnedIndicator() {
		return numberOfChecksReturnedIndicator;
	}
	public void setNumberOfChecksReturnedIndicator(
			String numberOfChecksReturnedIndicator) {
		this.numberOfChecksReturnedIndicator = numberOfChecksReturnedIndicator;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
	public String getReportDateEvent() {
		return reportDateEvent;
	}
	public void setReportDateEvent(String reportDateEvent) {
		this.reportDateEvent = reportDateEvent;
	}
	public String getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(String availableBalance) {
		this.availableBalance = availableBalance;
	}
	public String getInstallmentsOverdue() {
		return installmentsOverdue;
	}
	public void setInstallmentsOverdue(String installmentsOverdue) {
		this.installmentsOverdue = installmentsOverdue;
	}
	public String getPaymentDeadLine() {
		return paymentDeadLine;
	}
	public void setPaymentDeadLine(String paymentDeadLine) {
		this.paymentDeadLine = paymentDeadLine;
	}
	public String getMortgageSubsidy() {
		return mortgageSubsidy;
	}
	public void setMortgageSubsidy(String mortgageSubsidy) {
		this.mortgageSubsidy = mortgageSubsidy;
	}
	public String getMortgageSubsidyDate() {
		return mortgageSubsidyDate;
	}
	public void setMortgageSubsidyDate(String mortgageSubsidyDate) {
		this.mortgageSubsidyDate = mortgageSubsidyDate;
	}
	public String getProbablyOfDefault() {
		return probablyOfDefault;
	}
	public void setProbablyOfDefault(String probablyOfDefault) {
		this.probablyOfDefault = probablyOfDefault;
	}
	public String getTotalCashDebit() {
		return totalCashDebit;
	}
	public void setTotalCashDebit(String totalCashDebit) {
		this.totalCashDebit = totalCashDebit;
	}
	public String getTotalCashCredit() {
		return totalCashCredit;
	}
	public void setTotalCashCredit(String totalCashCredit) {
		this.totalCashCredit = totalCashCredit;
	}
	public String getTotalDebitTransfer() {
		return totalDebitTransfer;
	}
	public void setTotalDebitTransfer(String totalDebitTransfer) {
		this.totalDebitTransfer = totalDebitTransfer;
	}
	public String getTotalCreditTransfer() {
		return totalCreditTransfer;
	}
	public void setTotalCreditTransfer(String totalCreditTransfer) {
		this.totalCreditTransfer = totalCreditTransfer;
	}
	public String getNumberCheckPaid() {
		return numberCheckPaid;
	}
	public void setNumberCheckPaid(String numberCheckPaid) {
		this.numberCheckPaid = numberCheckPaid;
	}
	public String getTotalValueCheckReturned() {
		return totalValueCheckReturned;
	}
	public void setTotalValueCheckReturned(String totalValueCheckReturned) {
		this.totalValueCheckReturned = totalValueCheckReturned;
	}
	public String getTotalValueCheckPaid() {
		return totalValueCheckPaid;
	}
	public void setTotalValueCheckPaid(String totalValueCheckPaid) {
		this.totalValueCheckPaid = totalValueCheckPaid;
	}
	public String getResidenceCity() {
		return residenceCity;
	}
	public void setResidenceCity(String residenceCity) {
		this.residenceCity = residenceCity;
	}
	public String getDaneCityResidenceCode() {
		return daneCityResidenceCode;
	}
	public void setDaneCityResidenceCode(String daneCityResidenceCode) {
		this.daneCityResidenceCode = daneCityResidenceCode;
	}
	public String getResidenceDepartment() {
		return residenceDepartment;
	}
	public void setResidenceDepartment(String residenceDepartment) {
		this.residenceDepartment = residenceDepartment;
	}
	public String getResidenceAddress() {
		return residenceAddress;
	}
	public void setResidenceAddress(String residenceAddress) {
		this.residenceAddress = residenceAddress;
	}
	public String getResidencePhone() {
		return residencePhone;
	}
	public void setResidencePhone(String residencePhone) {
		this.residencePhone = residencePhone;
	}
	public String getDaneCityWorkCode() {
		return daneCityWorkCode;
	}
	public void setDaneCityWorkCode(String daneCityWorkCode) {
		this.daneCityWorkCode = daneCityWorkCode;
	}
	public String getWorkCity() {
		return workCity;
	}
	public void setWorkCity(String workCity) {
		this.workCity = workCity;
	}
	public String getWorkDepartment() {
		return workDepartment;
	}
	public void setWorkDepartment(String workDepartment) {
		this.workDepartment = workDepartment;
	}
	public String getWorkAddress() {
		return workAddress;
	}
	public void setWorkAddress(String workAddress) {
		this.workAddress = workAddress;
	}
	public String getWorkPhone() {
		return workPhone;
	}
	public void setWorkPhone(String workPhone) {
		this.workPhone = workPhone;
	}
	public String getDaneCityCorrespondenceCode() {
		return daneCityCorrespondenceCode;
	}
	public void setDaneCityCorrespondenceCode(String daneCityCorrespondenceCode) {
		this.daneCityCorrespondenceCode = daneCityCorrespondenceCode;
	}
	public String getCorrespondenceCity() {
		return correspondenceCity;
	}
	public void setCorrespondenceCity(String correspondenceCity) {
		this.correspondenceCity = correspondenceCity;
	}
	public String getCorrespondenceDepartment() {
		return correspondenceDepartment;
	}
	public void setCorrespondenceDepartment(String correspondenceDepartment) {
		this.correspondenceDepartment = correspondenceDepartment;
	}
	public String getCorrespondenceAddress() {
		return correspondenceAddress;
	}
	public void setCorrespondenceAddress(String correspondenceAddress) {
		this.correspondenceAddress = correspondenceAddress;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getScoreValue() {
		return scoreValue;
	}
	public void setScoreValue(String scoreValue) {
		this.scoreValue = scoreValue;
	}
	public String getOriginOfStatusAccount() {
		return originOfStatusAccount;
	}
	public void setOriginOfStatusAccount(String originOfStatusAccount) {
		this.originOfStatusAccount = originOfStatusAccount;
	}
	public String getGuaranteeDetail() {
		return guaranteeDetail;
	}
	public void setGuaranteeDetail(String guaranteeDetail) {
		this.guaranteeDetail = guaranteeDetail;
	}
	public String getTypeOfCredit() {
		return typeOfCredit;
	}
	public void setTypeOfCredit(String typeOfCredit) {
		this.typeOfCredit = typeOfCredit;
	}
	public String getLastYear() {
		return lastYear;
	}
	public void setLastYear(String lastYear) {
		this.lastYear = lastYear;
	}
	public String getLastMonth() {
		return lastMonth;
	}
	public void setLastMonth(String lastMonth) {
		this.lastMonth = lastMonth;
	}
	public String getInitialYear() {
		return initialYear;
	}
	public void setInitialYear(String initialYear) {
		this.initialYear = initialYear;
	}
	public String getInitialMonth() {
		return initialMonth;
	}
	public void setInitialMonth(String initialMonth) {
		this.initialMonth = initialMonth;
	}

}
