package co.com.experian.novedat.bridge.dto;

import lombok.Data;

@Data
public class ObligationInfoEnableDto {
    public Boolean event;//ICMCHK.NOV-REPORT-ABD06
    public Boolean accountType;
    public Boolean parameterizedAccountType;
    public Boolean impound;    //Número de Embargo
    public Boolean adjective; //ADJETIVO1-ABD07
    public Boolean adjective2; //ADJETIVO2-ABD07
    public Boolean adjective3; //ADJETIVO3-ABD07
    public Boolean parameterizedAdjective;
    public Boolean fillingOffice;     //oficina de radicacion NOMOFI-OFICINA /OFICINA-RADICACION-ICMVLR
    public Boolean statusOwner;     //19 situacionEstadoTitular  *******
    public Boolean parameterizedStatusOwner;
    public Boolean currencyType;
    public Boolean parameterizedCurrencyType;
    public Boolean dateOfAccountStatus; //ICMCRE.FECHA-ESTADO-OBLIG-ABD07
    public Boolean eventDate;     //Fecha Novedat
    public Boolean accountOpeningDate; //ICMCHK.FECHA-APERT-ABD06 / ICMCRE.FECHA-APERTURA-ABD07
    public Boolean feeValue; //ICMCRE.CUANTIA-ABD07
    public Boolean stateOfAccountHolder; //ICMCRE.SITUACION-TITULAR-ABD07
    public Boolean impoundDate; //Fecha que indica el último embargo de la cuenta.
    public Boolean adjectiveDate; //FECHA-ADJETIVO1-ABD07
    public Boolean adjectiveDate2; //FECHA-ADJETIVO2-ABD07 / ICMCRE.FEC-MAY-ADJ-ABD07
    public Boolean adjectiveDate3; //FECHA-ADJETIVO3-ABD07
    public Boolean fillingCity; //M-CIUDAD-RADICACION-VLR-MOD / NOMCIU-OFICINA / CIUDAD-RADICACION-ICMVLR
    public Boolean daneCitySettlementCode;     //Codigo Dane
    public Boolean rating; //M-CALIFICACION-CHK-MOD / ICMCRE.CALIFICACIONM-ABD07
    public Boolean numberOfChecksReturned;     //Cantidad de cheques devueltos
    public Boolean overdraftIndicator;     //Indicador de sobregiro
    public Boolean authorizedOverdraftCreditLimit; //Valor del cupo del sobregiro de la cuenta en miles de pesos
    public Boolean authorizedOverdraftDays;     //Dias de sobregiros
    public Boolean reportDateOverdraftDate; //Fecha en la que se reporta el cupo y/o días de sobregiro autorizado.
    public Boolean accountCategory; //Clase de Cuentas (ver APOYO.CLASE_CTA_CTE de DataCAS)
    public Boolean eventDate2; //Fecha Novedat dos duplicado en la trama detalle
    public Boolean parameterizedCity;
    public Boolean parameterizedEvent;
    public Boolean feeValueInd; //ICMCRE.CUANTIA-ABD07
    public Boolean initialValue;//VALOR-INICIAL-ABD07
    public Boolean debtBalance; //ICMCRE.VALOR-SALDO-DEUDAM-ABD07  //************POR VALIDAR CAMPO
    public Boolean valueBalanceOverdue; //ICMCRE.VALOR-SALDO-MORAM-ABD07 //************POR VALIDAR CAMPO
    public Boolean typeOfCreditInd;  //ICMCRE.TIPO-OBLIGACION-ABD07
    public Boolean totalValueOfChecksReturned; //ICMCRE.CUOTAS-CANCELADAS-ABD07
    public Boolean totalValueOfChecksPaid; //ICMCRE.TOTAL-CUOTAS-ABD07
    public Boolean situationDate; //ICMCRE.FECHA-SITUACION-ABD07 //************POR VALIDAR CAMPO  No esta en el XPM
    public Boolean periodicityOfPayments; //ICMCRE.PERIODICIDAD-PAGO-ABD07
    public Boolean typeOfDebtor;  //ICMCRE.GARANTE-ABD07
    public Boolean paymentType;//ICMCRE.FORMA-PAGO-TOTAL-ABD07
    public Boolean accountStatus; //ICMCRE.ESTADO-OBLIG-ABD07
    public Boolean originStatusOfAccount;  //ICMCRE.ESTADO-ORIGEN-ABD07
    public Boolean dateOfOriginStatus; //ICMCRE.FECHA-ESTADO-ORIGEN-ABD07
    public Boolean paymentDeadline; //ICMCRE.FECHA-LIMITE-PAGO-ABD07
    public Boolean paymentDate;//ICMCRE.FECHA-DE-PAGO-ABD07
    public Boolean probabilityOfDefault; //ICMCRE.PROBAB-INCUMP-ABD07
    public Boolean privateBrandName; //ICMCRE.TARJ-MARCA-PRIV-ABD07
    public Boolean cardClass;     //ICMCRE.TARJ-CLASE-ABD07
    public Boolean franchise;  //ICMCRE.TARJ-FRANQUICIA-ABD07
    public Boolean cardStatus;     //ICMCRE.TARJ-ESTADO-PLAST-ABD07
    public Boolean dateOfCardStatus;  //ICMCRE.TARJ-FEC-ESTADO-PLAST-ABD07
    public Boolean permanenceClause;   //ICMCRE.REAL-CLAUS-PERM-ABD07
    public Boolean contractType;    //ICMCRE.REAL-TERMINO-CONTRATO-ABD07
    public Boolean permanenceClauseDate;  //ICMCRE.REAL-FEC-CLAUS-PERM-ABD07
    public Boolean guaranteeType;     //ICMCRE.TIPO-GARANTIA-ABD07

    //Informacion adicional de campos
    public Boolean typeOfBlock; //ICMCHK.IND-BimpoundLOQUEO-ABD06 /ICMCRE.IND-BLOQUEO-ABD07
    public Boolean frequentBehaviour1; //VECTOR-HIS-1-ABD07
    public Boolean frequentBehaviour2; //ICMCRE.VECTOR-2-ABD07
    public Boolean frequentBehaviour3;  //VECTOR-HIS-3-ABD07
    public Boolean frequentBehaviour4; //VECTOR-HIS-4-ABD07
    public Boolean disputeIndicator; //ICMCHK.IND-RECLAMO-ABD06 / ICMCRE.IND-RECLAMO-ABD07
    public Boolean overdueDay; //ICMCRE.MOROSIDAD-ABD07*/

    public Boolean numberOfChecksReturnedIndicator;//Indicador de cheques devueltos
    public Boolean expiryDate; //ICMCRE.FECHA-VENCIMIENTO-ABD07
    /*CAMPOS NUEVOS UTILIZADOS EN LA INTERFAZ*/
    public Boolean reportDateEvent;
    public Boolean availableBalance;
    public Boolean installmentsOverdue;
    public Boolean paymentDeadLine;
    public Boolean mortgageSubsidyDate;
    public Boolean probablyOfDefault;
    public Boolean totalCashDebit;
    public Boolean totalCashCredit;
    public Boolean totalDebitTransfer;
    public Boolean totalCreditTransfer;
    public Boolean numberCheckPaid;
    public Boolean totalValueCheckReturned;
    public Boolean totalValueCheckPaid;
    public Boolean residenceCity;
    public Boolean daneCityResidenceCode;
    public Boolean residenceDepartment;
    public Boolean residenceAddress;
    public Boolean residencePhone;
    public Boolean daneCityWorkCode;
    public Boolean workCity;
    public Boolean workDepartment;
    public Boolean workAddress;
    public Boolean workPhone;
    public Boolean daneCityCorrespondenceCode;
    public Boolean correspondenceCity;
    public Boolean correspondenceDepartment;
    public Boolean correspondenceAddress;
    public Boolean email;
    public Boolean cardNumber;
    public Boolean city;
    public Boolean scoreValue;
    public Boolean originOfStatusAccount;
    public Boolean creditType;
    public Boolean guaranteeDetail;
}
