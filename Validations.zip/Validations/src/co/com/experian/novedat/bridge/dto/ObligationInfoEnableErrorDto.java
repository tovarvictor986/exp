package co.com.experian.novedat.bridge.dto;

import lombok.Data;

@Data
public class ObligationInfoEnableErrorDto {
    public Boolean event;//ICMCHK.NOV-REPORT-ABD06
    public Boolean accountType;
    public Boolean parameterizedAccountType;
    public Boolean impound;    //Número de Embargo
    public Boolean adjective; //ADJETIVO1-ABD07
    public Boolean adjective2; //ADJETIVO2-ABD07
    public Boolean adjective3; //ADJETIVO3-ABD07
    public Boolean parameterizedAdjective;
    public Boolean fillingOffice;     //oficina de radicacion NOMOFI-OFICINA /OFICINA-RADICACION-ICMVLR
    public Boolean statusOwner;     //19 situacionEstadoTitular  *******
    public Boolean parameterizedStatusOwner;
    public Boolean currencyType;
    public Boolean parameterizedCurrencyType;
    public Boolean dateOfAccountStatus; //ICMCRE.FECHA-ESTADO-OBLIG-ABD07
    public Boolean eventDate;     //Fecha Novedat
    public Boolean accountOpeningDate; //ICMCHK.FECHA-APERT-ABD06 / ICMCRE.FECHA-APERTURA-ABD07
    public Boolean feeValue; //ICMCRE.CUANTIA-ABD07
    public Boolean stateOfAccountHolder; //ICMCRE.SITUACION-TITULAR-ABD07
    public Boolean impoundDate; //Fecha que indica el último embargo de la cuenta.
    public Boolean adjectiveDate; //FECHA-ADJETIVO1-ABD07
    public Boolean adjectiveDate2; //FECHA-ADJETIVO2-ABD07 / ICMCRE.FEC-MAY-ADJ-ABD07
    public Boolean adjectiveDate3; //FECHA-ADJETIVO3-ABD07
    public Boolean fillingCity; //M-CIUDAD-RADICACION-VLR-MOD / NOMCIU-OFICINA / CIUDAD-RADICACION-ICMVLR
    public Boolean daneCitySettlementCode;     //Codigo Dane
    public Boolean rating; //M-CALIFICACION-CHK-MOD / ICMCRE.CALIFICACIONM-ABD07
    public Boolean numberOfChecksReturned;     //Cantidad de cheques devueltos
    public Boolean overdraftIndicator;     //Indicador de sobregiro
    public Boolean authorizedOverdraftCreditLimit; //Valor del cupo del sobregiro de la cuenta en miles de pesos
    public Boolean authorizedOverdraftDays;     //Dias de sobregiros
    public Boolean reportDateOverdraftDate; //Fecha en la que se reporta el cupo y/o días de sobregiro autorizado.
    public Boolean accountCategory; //Clase de Cuentas (ver APOYO.CLASE_CTA_CTE de DataCAS)
    public Boolean eventDate2; //Fecha Novedat dos duplicado en la trama detalle
    public Boolean parameterizedCity;
    public Boolean parameterizedEvent;
    public Boolean feeValueInd; //ICMCRE.CUANTIA-ABD07
    public Boolean initialValue;//VALOR-INICIAL-ABD07
    public Boolean debtBalance; //ICMCRE.VALOR-SALDO-DEUDAM-ABD07  //************POR VALIDAR CAMPO
    public Boolean valueBalanceOverdue; //ICMCRE.VALOR-SALDO-MORAM-ABD07 //************POR VALIDAR CAMPO
    public Boolean typeOfCreditInd;  //ICMCRE.TIPO-OBLIGACION-ABD07
    public Boolean totalValueOfChecksReturned; //ICMCRE.CUOTAS-CANCELADAS-ABD07
    public Boolean totalValueOfChecksPaid; //ICMCRE.TOTAL-CUOTAS-ABD07
    public Boolean situationDate; //ICMCRE.FECHA-SITUACION-ABD07 //************POR VALIDAR CAMPO  No esta en el XPM
    public Boolean periodicityOfPayments; //ICMCRE.PERIODICIDAD-PAGO-ABD07
    public Boolean typeOfDebtor;  //ICMCRE.GARANTE-ABD07
    public Boolean paymentType;//ICMCRE.FORMA-PAGO-TOTAL-ABD07
    public Boolean accountStatus; //ICMCRE.ESTADO-OBLIG-ABD07
    public Boolean originStatusOfAccount;  //ICMCRE.ESTADO-ORIGEN-ABD07
    public Boolean dateOfOriginStatus; //ICMCRE.FECHA-ESTADO-ORIGEN-ABD07
    public Boolean paymentDeadline; //ICMCRE.FECHA-LIMITE-PAGO-ABD07
    public Boolean paymentDate;//ICMCRE.FECHA-DE-PAGO-ABD07
    public Boolean probabilityOfDefault; //ICMCRE.PROBAB-INCUMP-ABD07
    public Boolean privateBrandName; //ICMCRE.TARJ-MARCA-PRIV-ABD07
    public Boolean cardClass;     //ICMCRE.TARJ-CLASE-ABD07
    public Boolean franchise;  //ICMCRE.TARJ-FRANQUICIA-ABD07
    public Boolean cardStatus;     //ICMCRE.TARJ-ESTADO-PLAST-ABD07
    public Boolean dateOfCardStatus;  //ICMCRE.TARJ-FEC-ESTADO-PLAST-ABD07
    public Boolean permanenceClause;   //ICMCRE.REAL-CLAUS-PERM-ABD07
    public Boolean contractType;    //ICMCRE.REAL-TERMINO-CONTRATO-ABD07
    public Boolean permanenceClauseDate;  //ICMCRE.REAL-FEC-CLAUS-PERM-ABD07
    public Boolean guaranteeType;     //ICMCRE.TIPO-GARANTIA-ABD07

    //Informacion adicional de campos
    public Boolean typeOfBlock; //ICMCHK.IND-BimpoundLOQUEO-ABD06 /ICMCRE.IND-BLOQUEO-ABD07
    public Boolean frequentBehaviour1; //VECTOR-HIS-1-ABD07
    public Boolean frequentBehaviour2; //ICMCRE.VECTOR-2-ABD07
    public Boolean frequentBehaviour3;  //VECTOR-HIS-3-ABD07
    public Boolean frequentBehaviour4; //VECTOR-HIS-4-ABD07
    public Boolean disputeIndicator; //ICMCHK.IND-RECLAMO-ABD06 / ICMCRE.IND-RECLAMO-ABD07
    public Boolean overdueDay; //ICMCRE.MOROSIDAD-ABD07*/

    public Boolean numberOfChecksReturnedIndicator;//Indicador de cheques devueltos
    public Boolean expiryDate; //ICMCRE.FECHA-VENCIMIENTO-ABD07
    /*CAMPOS NUEVOS UTILIZADOS EN LA INTERFAZ*/
    public Boolean reportDateEvent;
    public Boolean availableBalance;
    public Boolean installmentsOverdue;
    public Boolean paymentDeadLine;
    public Boolean mortgageSubsidyDate;
    public Boolean probablyOfDefault;
    public Boolean totalCashDebit;
    public Boolean totalCashCredit;
    public Boolean totalDebitTransfer;
    public Boolean totalCreditTransfer;
    public Boolean numberCheckPaid;
    public Boolean totalValueCheckReturned;
    public Boolean totalValueCheckPaid;
    public Boolean residenceCity;
    public Boolean daneCityResidenceCode;
    public Boolean residenceDepartment;
    public Boolean residenceAddress;
    public Boolean residencePhone;
    public Boolean daneCityWorkCode;
    public Boolean workCity;
    public Boolean workDepartment;
    public Boolean workAddress;
    public Boolean workPhone;
    public Boolean daneCityCorrespondenceCode;
    public Boolean correspondenceCity;
    public Boolean correspondenceDepartment;
    public Boolean correspondenceAddress;
    public Boolean email;
    public Boolean cardNumber;
    public Boolean city;
    public Boolean scoreValue;
    public Boolean originOfStatusAccount;
    public Boolean creditType;
    public Boolean guaranteeDetail;
	public Boolean getEvent() {
		return event;
	}
	public void setEvent(Boolean event) {
		this.event = event;
	}
	public Boolean getAccountType() {
		return accountType;
	}
	public void setAccountType(Boolean accountType) {
		this.accountType = accountType;
	}
	public Boolean getParameterizedAccountType() {
		return parameterizedAccountType;
	}
	public void setParameterizedAccountType(Boolean parameterizedAccountType) {
		this.parameterizedAccountType = parameterizedAccountType;
	}
	public Boolean getImpound() {
		return impound;
	}
	public void setImpound(Boolean impound) {
		this.impound = impound;
	}
	public Boolean getAdjective() {
		return adjective;
	}
	public void setAdjective(Boolean adjective) {
		this.adjective = adjective;
	}
	public Boolean getAdjective2() {
		return adjective2;
	}
	public void setAdjective2(Boolean adjective2) {
		this.adjective2 = adjective2;
	}
	public Boolean getAdjective3() {
		return adjective3;
	}
	public void setAdjective3(Boolean adjective3) {
		this.adjective3 = adjective3;
	}
	public Boolean getParameterizedAdjective() {
		return parameterizedAdjective;
	}
	public void setParameterizedAdjective(Boolean parameterizedAdjective) {
		this.parameterizedAdjective = parameterizedAdjective;
	}
	public Boolean getFillingOffice() {
		return fillingOffice;
	}
	public void setFillingOffice(Boolean fillingOffice) {
		this.fillingOffice = fillingOffice;
	}
	public Boolean getStatusOwner() {
		return statusOwner;
	}
	public void setStatusOwner(Boolean statusOwner) {
		this.statusOwner = statusOwner;
	}
	public Boolean getParameterizedStatusOwner() {
		return parameterizedStatusOwner;
	}
	public void setParameterizedStatusOwner(Boolean parameterizedStatusOwner) {
		this.parameterizedStatusOwner = parameterizedStatusOwner;
	}
	public Boolean getCurrencyType() {
		return currencyType;
	}
	public void setCurrencyType(Boolean currencyType) {
		this.currencyType = currencyType;
	}
	public Boolean getParameterizedCurrencyType() {
		return parameterizedCurrencyType;
	}
	public void setParameterizedCurrencyType(Boolean parameterizedCurrencyType) {
		this.parameterizedCurrencyType = parameterizedCurrencyType;
	}
	public Boolean getDateOfAccountStatus() {
		return dateOfAccountStatus;
	}
	public void setDateOfAccountStatus(Boolean dateOfAccountStatus) {
		this.dateOfAccountStatus = dateOfAccountStatus;
	}
	public Boolean getEventDate() {
		return eventDate;
	}
	public void setEventDate(Boolean eventDate) {
		this.eventDate = eventDate;
	}
	public Boolean getAccountOpeningDate() {
		return accountOpeningDate;
	}
	public void setAccountOpeningDate(Boolean accountOpeningDate) {
		this.accountOpeningDate = accountOpeningDate;
	}
	public Boolean getFeeValue() {
		return feeValue;
	}
	public void setFeeValue(Boolean feeValue) {
		this.feeValue = feeValue;
	}
	public Boolean getStateOfAccountHolder() {
		return stateOfAccountHolder;
	}
	public void setStateOfAccountHolder(Boolean stateOfAccountHolder) {
		this.stateOfAccountHolder = stateOfAccountHolder;
	}
	public Boolean getImpoundDate() {
		return impoundDate;
	}
	public void setImpoundDate(Boolean impoundDate) {
		this.impoundDate = impoundDate;
	}
	public Boolean getAdjectiveDate() {
		return adjectiveDate;
	}
	public void setAdjectiveDate(Boolean adjectiveDate) {
		this.adjectiveDate = adjectiveDate;
	}
	public Boolean getAdjectiveDate2() {
		return adjectiveDate2;
	}
	public void setAdjectiveDate2(Boolean adjectiveDate2) {
		this.adjectiveDate2 = adjectiveDate2;
	}
	public Boolean getAdjectiveDate3() {
		return adjectiveDate3;
	}
	public void setAdjectiveDate3(Boolean adjectiveDate3) {
		this.adjectiveDate3 = adjectiveDate3;
	}
	public Boolean getFillingCity() {
		return fillingCity;
	}
	public void setFillingCity(Boolean fillingCity) {
		this.fillingCity = fillingCity;
	}
	public Boolean getDaneCitySettlementCode() {
		return daneCitySettlementCode;
	}
	public void setDaneCitySettlementCode(Boolean daneCitySettlementCode) {
		this.daneCitySettlementCode = daneCitySettlementCode;
	}
	public Boolean getRating() {
		return rating;
	}
	public void setRating(Boolean rating) {
		this.rating = rating;
	}
	public Boolean getNumberOfChecksReturned() {
		return numberOfChecksReturned;
	}
	public void setNumberOfChecksReturned(Boolean numberOfChecksReturned) {
		this.numberOfChecksReturned = numberOfChecksReturned;
	}
	public Boolean getOverdraftIndicator() {
		return overdraftIndicator;
	}
	public void setOverdraftIndicator(Boolean overdraftIndicator) {
		this.overdraftIndicator = overdraftIndicator;
	}
	public Boolean getAuthorizedOverdraftCreditLimit() {
		return authorizedOverdraftCreditLimit;
	}
	public void setAuthorizedOverdraftCreditLimit(
			Boolean authorizedOverdraftCreditLimit) {
		this.authorizedOverdraftCreditLimit = authorizedOverdraftCreditLimit;
	}
	public Boolean getAuthorizedOverdraftDays() {
		return authorizedOverdraftDays;
	}
	public void setAuthorizedOverdraftDays(Boolean authorizedOverdraftDays) {
		this.authorizedOverdraftDays = authorizedOverdraftDays;
	}
	public Boolean getReportDateOverdraftDate() {
		return reportDateOverdraftDate;
	}
	public void setReportDateOverdraftDate(Boolean reportDateOverdraftDate) {
		this.reportDateOverdraftDate = reportDateOverdraftDate;
	}
	public Boolean getAccountCategory() {
		return accountCategory;
	}
	public void setAccountCategory(Boolean accountCategory) {
		this.accountCategory = accountCategory;
	}
	public Boolean getEventDate2() {
		return eventDate2;
	}
	public void setEventDate2(Boolean eventDate2) {
		this.eventDate2 = eventDate2;
	}
	public Boolean getParameterizedCity() {
		return parameterizedCity;
	}
	public void setParameterizedCity(Boolean parameterizedCity) {
		this.parameterizedCity = parameterizedCity;
	}
	public Boolean getParameterizedEvent() {
		return parameterizedEvent;
	}
	public void setParameterizedEvent(Boolean parameterizedEvent) {
		this.parameterizedEvent = parameterizedEvent;
	}
	public Boolean getFeeValueInd() {
		return feeValueInd;
	}
	public void setFeeValueInd(Boolean feeValueInd) {
		this.feeValueInd = feeValueInd;
	}
	public Boolean getInitialValue() {
		return initialValue;
	}
	public void setInitialValue(Boolean initialValue) {
		this.initialValue = initialValue;
	}
	public Boolean getDebtBalance() {
		return debtBalance;
	}
	public void setDebtBalance(Boolean debtBalance) {
		this.debtBalance = debtBalance;
	}
	public Boolean getValueBalanceOverdue() {
		return valueBalanceOverdue;
	}
	public void setValueBalanceOverdue(Boolean valueBalanceOverdue) {
		this.valueBalanceOverdue = valueBalanceOverdue;
	}
	public Boolean getTypeOfCreditInd() {
		return typeOfCreditInd;
	}
	public void setTypeOfCreditInd(Boolean typeOfCreditInd) {
		this.typeOfCreditInd = typeOfCreditInd;
	}
	public Boolean getTotalValueOfChecksReturned() {
		return totalValueOfChecksReturned;
	}
	public void setTotalValueOfChecksReturned(Boolean totalValueOfChecksReturned) {
		this.totalValueOfChecksReturned = totalValueOfChecksReturned;
	}
	public Boolean getTotalValueOfChecksPaid() {
		return totalValueOfChecksPaid;
	}
	public void setTotalValueOfChecksPaid(Boolean totalValueOfChecksPaid) {
		this.totalValueOfChecksPaid = totalValueOfChecksPaid;
	}
	public Boolean getSituationDate() {
		return situationDate;
	}
	public void setSituationDate(Boolean situationDate) {
		this.situationDate = situationDate;
	}
	public Boolean getPeriodicityOfPayments() {
		return periodicityOfPayments;
	}
	public void setPeriodicityOfPayments(Boolean periodicityOfPayments) {
		this.periodicityOfPayments = periodicityOfPayments;
	}
	public Boolean getTypeOfDebtor() {
		return typeOfDebtor;
	}
	public void setTypeOfDebtor(Boolean typeOfDebtor) {
		this.typeOfDebtor = typeOfDebtor;
	}
	public Boolean getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(Boolean paymentType) {
		this.paymentType = paymentType;
	}
	public Boolean getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(Boolean accountStatus) {
		this.accountStatus = accountStatus;
	}
	public Boolean getOriginStatusOfAccount() {
		return originStatusOfAccount;
	}
	public void setOriginStatusOfAccount(Boolean originStatusOfAccount) {
		this.originStatusOfAccount = originStatusOfAccount;
	}
	public Boolean getDateOfOriginStatus() {
		return dateOfOriginStatus;
	}
	public void setDateOfOriginStatus(Boolean dateOfOriginStatus) {
		this.dateOfOriginStatus = dateOfOriginStatus;
	}
	public Boolean getPaymentDeadline() {
		return paymentDeadline;
	}
	public void setPaymentDeadline(Boolean paymentDeadline) {
		this.paymentDeadline = paymentDeadline;
	}
	public Boolean getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(Boolean paymentDate) {
		this.paymentDate = paymentDate;
	}
	public Boolean getProbabilityOfDefault() {
		return probabilityOfDefault;
	}
	public void setProbabilityOfDefault(Boolean probabilityOfDefault) {
		this.probabilityOfDefault = probabilityOfDefault;
	}
	public Boolean getPrivateBrandName() {
		return privateBrandName;
	}
	public void setPrivateBrandName(Boolean privateBrandName) {
		this.privateBrandName = privateBrandName;
	}
	public Boolean getCardClass() {
		return cardClass;
	}
	public void setCardClass(Boolean cardClass) {
		this.cardClass = cardClass;
	}
	public Boolean getFranchise() {
		return franchise;
	}
	public void setFranchise(Boolean franchise) {
		this.franchise = franchise;
	}
	public Boolean getCardStatus() {
		return cardStatus;
	}
	public void setCardStatus(Boolean cardStatus) {
		this.cardStatus = cardStatus;
	}
	public Boolean getDateOfCardStatus() {
		return dateOfCardStatus;
	}
	public void setDateOfCardStatus(Boolean dateOfCardStatus) {
		this.dateOfCardStatus = dateOfCardStatus;
	}
	public Boolean getPermanenceClause() {
		return permanenceClause;
	}
	public void setPermanenceClause(Boolean permanenceClause) {
		this.permanenceClause = permanenceClause;
	}
	public Boolean getContractType() {
		return contractType;
	}
	public void setContractType(Boolean contractType) {
		this.contractType = contractType;
	}
	public Boolean getPermanenceClauseDate() {
		return permanenceClauseDate;
	}
	public void setPermanenceClauseDate(Boolean permanenceClauseDate) {
		this.permanenceClauseDate = permanenceClauseDate;
	}
	public Boolean getGuaranteeType() {
		return guaranteeType;
	}
	public void setGuaranteeType(Boolean guaranteeType) {
		this.guaranteeType = guaranteeType;
	}
	public Boolean getTypeOfBlock() {
		return typeOfBlock;
	}
	public void setTypeOfBlock(Boolean typeOfBlock) {
		this.typeOfBlock = typeOfBlock;
	}
	public Boolean getFrequentBehaviour1() {
		return frequentBehaviour1;
	}
	public void setFrequentBehaviour1(Boolean frequentBehaviour1) {
		this.frequentBehaviour1 = frequentBehaviour1;
	}
	public Boolean getFrequentBehaviour2() {
		return frequentBehaviour2;
	}
	public void setFrequentBehaviour2(Boolean frequentBehaviour2) {
		this.frequentBehaviour2 = frequentBehaviour2;
	}
	public Boolean getFrequentBehaviour3() {
		return frequentBehaviour3;
	}
	public void setFrequentBehaviour3(Boolean frequentBehaviour3) {
		this.frequentBehaviour3 = frequentBehaviour3;
	}
	public Boolean getFrequentBehaviour4() {
		return frequentBehaviour4;
	}
	public void setFrequentBehaviour4(Boolean frequentBehaviour4) {
		this.frequentBehaviour4 = frequentBehaviour4;
	}
	public Boolean getDisputeIndicator() {
		return disputeIndicator;
	}
	public void setDisputeIndicator(Boolean disputeIndicator) {
		this.disputeIndicator = disputeIndicator;
	}
	public Boolean getOverdueDay() {
		return overdueDay;
	}
	public void setOverdueDay(Boolean overdueDay) {
		this.overdueDay = overdueDay;
	}
	public Boolean getNumberOfChecksReturnedIndicator() {
		return numberOfChecksReturnedIndicator;
	}
	public void setNumberOfChecksReturnedIndicator(
			Boolean numberOfChecksReturnedIndicator) {
		this.numberOfChecksReturnedIndicator = numberOfChecksReturnedIndicator;
	}
	public Boolean getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(Boolean expiryDate) {
		this.expiryDate = expiryDate;
	}
	public Boolean getReportDateEvent() {
		return reportDateEvent;
	}
	public void setReportDateEvent(Boolean reportDateEvent) {
		this.reportDateEvent = reportDateEvent;
	}
	public Boolean getAvailableBalance() {
		return availableBalance;
	}
	public void setAvailableBalance(Boolean availableBalance) {
		this.availableBalance = availableBalance;
	}
	public Boolean getInstallmentsOverdue() {
		return installmentsOverdue;
	}
	public void setInstallmentsOverdue(Boolean installmentsOverdue) {
		this.installmentsOverdue = installmentsOverdue;
	}
	public Boolean getPaymentDeadLine() {
		return paymentDeadLine;
	}
	public void setPaymentDeadLine(Boolean paymentDeadLine) {
		this.paymentDeadLine = paymentDeadLine;
	}
	public Boolean getMortgageSubsidyDate() {
		return mortgageSubsidyDate;
	}
	public void setMortgageSubsidyDate(Boolean mortgageSubsidyDate) {
		this.mortgageSubsidyDate = mortgageSubsidyDate;
	}
	public Boolean getProbablyOfDefault() {
		return probablyOfDefault;
	}
	public void setProbablyOfDefault(Boolean probablyOfDefault) {
		this.probablyOfDefault = probablyOfDefault;
	}
	public Boolean getTotalCashDebit() {
		return totalCashDebit;
	}
	public void setTotalCashDebit(Boolean totalCashDebit) {
		this.totalCashDebit = totalCashDebit;
	}
	public Boolean getTotalCashCredit() {
		return totalCashCredit;
	}
	public void setTotalCashCredit(Boolean totalCashCredit) {
		this.totalCashCredit = totalCashCredit;
	}
	public Boolean getTotalDebitTransfer() {
		return totalDebitTransfer;
	}
	public void setTotalDebitTransfer(Boolean totalDebitTransfer) {
		this.totalDebitTransfer = totalDebitTransfer;
	}
	public Boolean getTotalCreditTransfer() {
		return totalCreditTransfer;
	}
	public void setTotalCreditTransfer(Boolean totalCreditTransfer) {
		this.totalCreditTransfer = totalCreditTransfer;
	}
	public Boolean getNumberCheckPaid() {
		return numberCheckPaid;
	}
	public void setNumberCheckPaid(Boolean numberCheckPaid) {
		this.numberCheckPaid = numberCheckPaid;
	}
	public Boolean getTotalValueCheckReturned() {
		return totalValueCheckReturned;
	}
	public void setTotalValueCheckReturned(Boolean totalValueCheckReturned) {
		this.totalValueCheckReturned = totalValueCheckReturned;
	}
	public Boolean getTotalValueCheckPaid() {
		return totalValueCheckPaid;
	}
	public void setTotalValueCheckPaid(Boolean totalValueCheckPaid) {
		this.totalValueCheckPaid = totalValueCheckPaid;
	}
	public Boolean getResidenceCity() {
		return residenceCity;
	}
	public void setResidenceCity(Boolean residenceCity) {
		this.residenceCity = residenceCity;
	}
	public Boolean getDaneCityResidenceCode() {
		return daneCityResidenceCode;
	}
	public void setDaneCityResidenceCode(Boolean daneCityResidenceCode) {
		this.daneCityResidenceCode = daneCityResidenceCode;
	}
	public Boolean getResidenceDepartment() {
		return residenceDepartment;
	}
	public void setResidenceDepartment(Boolean residenceDepartment) {
		this.residenceDepartment = residenceDepartment;
	}
	public Boolean getResidenceAddress() {
		return residenceAddress;
	}
	public void setResidenceAddress(Boolean residenceAddress) {
		this.residenceAddress = residenceAddress;
	}
	public Boolean getResidencePhone() {
		return residencePhone;
	}
	public void setResidencePhone(Boolean residencePhone) {
		this.residencePhone = residencePhone;
	}
	public Boolean getDaneCityWorkCode() {
		return daneCityWorkCode;
	}
	public void setDaneCityWorkCode(Boolean daneCityWorkCode) {
		this.daneCityWorkCode = daneCityWorkCode;
	}
	public Boolean getWorkCity() {
		return workCity;
	}
	public void setWorkCity(Boolean workCity) {
		this.workCity = workCity;
	}
	public Boolean getWorkDepartment() {
		return workDepartment;
	}
	public void setWorkDepartment(Boolean workDepartment) {
		this.workDepartment = workDepartment;
	}
	public Boolean getWorkAddress() {
		return workAddress;
	}
	public void setWorkAddress(Boolean workAddress) {
		this.workAddress = workAddress;
	}
	public Boolean getWorkPhone() {
		return workPhone;
	}
	public void setWorkPhone(Boolean workPhone) {
		this.workPhone = workPhone;
	}
	public Boolean getDaneCityCorrespondenceCode() {
		return daneCityCorrespondenceCode;
	}
	public void setDaneCityCorrespondenceCode(Boolean daneCityCorrespondenceCode) {
		this.daneCityCorrespondenceCode = daneCityCorrespondenceCode;
	}
	public Boolean getCorrespondenceCity() {
		return correspondenceCity;
	}
	public void setCorrespondenceCity(Boolean correspondenceCity) {
		this.correspondenceCity = correspondenceCity;
	}
	public Boolean getCorrespondenceDepartment() {
		return correspondenceDepartment;
	}
	public void setCorrespondenceDepartment(Boolean correspondenceDepartment) {
		this.correspondenceDepartment = correspondenceDepartment;
	}
	public Boolean getCorrespondenceAddress() {
		return correspondenceAddress;
	}
	public void setCorrespondenceAddress(Boolean correspondenceAddress) {
		this.correspondenceAddress = correspondenceAddress;
	}
	public Boolean getEmail() {
		return email;
	}
	public void setEmail(Boolean email) {
		this.email = email;
	}
	public Boolean getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(Boolean cardNumber) {
		this.cardNumber = cardNumber;
	}
	public Boolean getCity() {
		return city;
	}
	public void setCity(Boolean city) {
		this.city = city;
	}
	public Boolean getScoreValue() {
		return scoreValue;
	}
	public void setScoreValue(Boolean scoreValue) {
		this.scoreValue = scoreValue;
	}
	public Boolean getOriginOfStatusAccount() {
		return originOfStatusAccount;
	}
	public void setOriginOfStatusAccount(Boolean originOfStatusAccount) {
		this.originOfStatusAccount = originOfStatusAccount;
	}
	public Boolean getCreditType() {
		return creditType;
	}
	public void setCreditType(Boolean creditType) {
		this.creditType = creditType;
	}
	public Boolean getGuaranteeDetail() {
		return guaranteeDetail;
	}
	public void setGuaranteeDetail(Boolean guaranteeDetail) {
		this.guaranteeDetail = guaranteeDetail;
	}    
    
}
