package co.com.experian.novedat.bridge.dto;

public class RegisterInfoDto {
}
