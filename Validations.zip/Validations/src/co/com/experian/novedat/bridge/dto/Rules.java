package co.com.experian.novedat.bridge.dto;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import co.com.experian.novedat.validations.dto.ObjectConditions;
import co.com.experian.novedat.validations.util.Utils;

public class Rules {
	private String caseType;
	private String value1;
	private String value2;
	private String typeData1;
	private String typeData2;
	private String operador;
	private String constante;
	private String compuesto;
	private String lista;
	private String msgError;
	private List<String> listMessages = new ArrayList<>();
	private String format = "yyyy-mm-dd";

	Utils utilities = new Utils();

	public static final String isTrue = "1";
	public static final String isFalse = "0";

	// public static final int isList = 1;

	// Method for validate the case type
	// Metodo principal
	public void verificarTipoCaso(ObjectConditions objC, ObligationInfoDto objV) {

		this.value1 = utilities.extractValue(objV, objC.getFieldName1());
		this.value2 = utilities.extractValue(objV, objC.getFieldName2());
		this.typeData1 = validateDataType(this.value1);
		this.typeData2 = validateDataType(this.value2);
		this.operador = objC.getConOperator();
		this.constante = objC.getConIsConstant();
		this.compuesto = objC.getConIsComposite();
		this.lista = objC.getConIsValueList();

		boolean reponse = false;
		// Case #1 => 1+1+1
		if (this.constante.equals(isTrue) && this.compuesto.equals(isTrue)
				&& this.lista.equals(isTrue)) {
			reponse = applicationTypeCase(objC, 1);
		}
		// Case #2 => 1+1+0
		if (this.constante.equals(isTrue) && this.compuesto.equals(isTrue)
				&& this.lista.equals(isFalse)) {
			reponse = applicationTypeCase(objC, 2);
		}
		// Case #3 => 0+1+1
		if (this.constante.equals(isFalse) && this.compuesto.equals(isTrue)
				&& this.lista.equals(isTrue)) {
			reponse = applicationTypeCase(objC, 3);
		}
		// Case #4 => 1+0+0
		if (this.constante.equals(isTrue) && this.compuesto.equals(isFalse)
				&& this.lista.equals(isFalse)) {
			reponse = applicationTypeCase(objC, 4);
		}
		// Case #5 => 0+0+1
		if (this.constante.equals(isFalse) && this.compuesto.equals(isFalse)
				&& this.lista.equals(isTrue)) {
			reponse = applicationTypeCase(objC, 5);
		}
		// Case #6 => 0+0+0
		if (this.constante.equals(isFalse) && this.compuesto.equals(isFalse)
				&& this.lista.equals(isFalse)) {
			reponse = applicationTypeCase(objC, 6);
		}
	}

	// De acuerdo a tipo de caso ejecuta las combinacion de reglas requeridas
	// sobre los valores
	public boolean applicationTypeCase(ObjectConditions objC, Integer typeCase) {
		boolean response = false;
		if (typeCase == 1)
			response = generalCompare(this.value1, objC.getConValue(),
					objC.getConOperator())
					&& searchInList(this.value2, objC.getValuesList());

		if (typeCase == 2)
			response = generalCompare(this.value1, this.value2,
					objC.getConOperator())
					&& generalCompare(this.value2, this.value2,
							objC.getConOperator());

		if (typeCase == 3)
			response = generalCompare(this.value1, this.value2,
					objC.getConOperator())
					&& searchInList(this.value2, objC.getValuesList());

		if (typeCase == 4)
			response = generalCompare(this.value1, objC.getConValue(),
					objC.getConOperator());

		if (typeCase == 5)
			response = searchInList(this.value1, objC.getValuesList());

		if (typeCase == 6)
			response = generalCompare(this.value1, objC.getConValue(),
					objC.getConOperator());

		return response;
	}

	// metodo general que recibe 2 objetos cualquiera y un operado
	public boolean generalCompare(Object obj1, Object obj2, String op) {
		boolean response = false;
		if (utilities.isNumeric(String.valueOf(obj1))) {
			response = compareNumeric(obj1.toString(), obj2.toString(), op);
			return response;
		}
		if (utilities.isThisDateValid(obj1.toString(), this.format)) {
			response = compareDate(obj1.toString(), obj2.toString(), op);
			return response;
		}
		return response;
	}

	// Validate data type
	public String validateDataType(String value) {
		String response = "Invalido";
		if (utilities.isNumeric(value)) {
			response = "Numeric";
		}
		if (utilities.isThisDateValid(value, this.format)) {
			response = "Date";
		}
		return response;
	}

	// comparar 2 fechas
	public boolean compareDate(String d1, String d2, String op) {
		boolean response = false;
		try {
			SimpleDateFormat sdf = new SimpleDateFormat(this.format);
			Date date1 = sdf.parse(d1);
			Date date2 = sdf.parse(d2);
			switch (op) {
			case "<":
				if (date1.after(date2) || date1.equals(date2)) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			case ">":
				if (date1.before(date2) || date1.equals(date2)) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			case "=":
				if (!(date2.equals(date1))) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			case "<=":
				if ((date1.after(date2))) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
			case ">=":
				if ((date1.before(date2))) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return response;
	}

	// comparar 2 numeros
	public boolean compareNumeric(String I1, String I2, String op) {
		boolean response = false;
		try {
			Integer int1 = Integer.parseInt(I1);
			Integer int2 = Integer.parseInt(I2);
			switch (op) {
			case "<":
				if (int1 > int2) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			case ">":
				if (int1 < int2) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			case "=":
				if (!(int1.equals(int2))) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			case "<=":
				if ((int1 > (int2))) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
			case ">=":
				if (int1 < int2) {
					// this.msgError = desc;
					listMessages.add(msgError);
					response = true;
				}
				break;
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return response;
	}

	// buscar un valor dentro de una lista
	public boolean searchInList(String value, List<String> list) {
		boolean response = false;
		for (String str : list) {
			if (str.equals(value)) {
				response = true;
				break;
			}
		}
		return response;
	}
}
