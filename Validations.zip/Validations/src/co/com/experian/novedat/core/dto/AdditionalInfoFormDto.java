package co.com.experian.novedat.core.dto;

import java.io.Serializable;

public class AdditionalInfoFormDto implements Serializable {

    private Boolean inModification;
    private Boolean inDelete;
    private Boolean inTrasmit;
    private Boolean inRatificate;

    public Boolean getInModification() {
        return inModification;
    }

    public void setInModification(Boolean inModification) {
        this.inModification = inModification;
    }

    public Boolean getInDelete() {
        return inDelete;
    }

    public void setInDelete(Boolean inDelete) {
        this.inDelete = inDelete;
    }

    public Boolean getInTrasmit() {
        return inTrasmit;
    }

    public void setInTrasmit(Boolean inTrasmit) {
        this.inTrasmit = inTrasmit;
    }

    public Boolean getInRatificate() {
        return inRatificate;
    }

    public void setInRatificate(Boolean inRatificate) {
        this.inRatificate = inRatificate;
    }
}
