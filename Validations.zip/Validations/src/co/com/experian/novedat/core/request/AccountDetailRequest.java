package co.com.experian.novedat.core.request;

import co.com.experian.novedat.bridge.dto.*;
import co.com.experian.novedat.core.dto.AdditionalInfoFormDto;

import java.io.Serializable;

/**
 * Created by Anderson Q.
 */
public class AccountDetailRequest implements Serializable {

    private AdditionalInfoDto additionalInfoDto;
    private ObligationInfoDto obligationInfoDto;
    private RegisterInfoDto registerInfoDto;
    private IndicatorInfoDto indicatorInfoDto;
    private ObligationInfoEnableDto obligationInfoEnableDto;
    private AdditionalInfoFormDto additionalInfoFormDto;

    public AdditionalInfoDto getAdditionalInfoDto() {
        return additionalInfoDto;
    }

    public void setAdditionalInfoDto(AdditionalInfoDto additionalInfoDto) {
        this.additionalInfoDto = additionalInfoDto;
    }

    public ObligationInfoDto getObligationInfoDto() {
        return obligationInfoDto;
    }

    public void setObligationInfoDto(ObligationInfoDto obligationInfoDto) {
        this.obligationInfoDto = obligationInfoDto;
    }

    public RegisterInfoDto getRegisterInfoDto() {
        return registerInfoDto;
    }

    public void setRegisterInfoDto(RegisterInfoDto registerInfoDto) {
        this.registerInfoDto = registerInfoDto;
    }

    public IndicatorInfoDto getIndicatorInfoDto() {
        return indicatorInfoDto;
    }

    public void setIndicatorInfoDto(IndicatorInfoDto indicatorInfoDto) {
        this.indicatorInfoDto = indicatorInfoDto;
    }

    public ObligationInfoEnableDto getObligationInfoEnableDto() {
        return obligationInfoEnableDto;
    }

    public void setObligationInfoEnableDto(ObligationInfoEnableDto obligationInfoEnableDto) {
        this.obligationInfoEnableDto = obligationInfoEnableDto;
    }

    public AdditionalInfoFormDto getAdditionalInfoFormDto() {
        return additionalInfoFormDto;
    }

    public void setAdditionalInfoFormDto(AdditionalInfoFormDto additionalInfoFormDto) {
        this.additionalInfoFormDto = additionalInfoFormDto;
    }
}
