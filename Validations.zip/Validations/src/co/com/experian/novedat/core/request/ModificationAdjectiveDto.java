package co.com.experian.novedat.core.request;

import java.io.Serializable;

public class ModificationAdjectiveDto implements Serializable {

    private Long idModificationCommon;
    private Long idModification;
    private String idAdjective;
    private String AdjectiveDate;
    private Long order;

    public Long getIdModificationCommon() {
        return idModificationCommon;
    }

    public void setIdModificationCommon(Long idModificationCommon) {
        this.idModificationCommon = idModificationCommon;
    }

    public Long getIdModification() {
        return idModification;
    }

    public void setIdModification(Long idModification) {
        this.idModification = idModification;
    }

    public String getIdAdjective() {
        return idAdjective;
    }

    public void setIdAdjective(String idAdjective) {
        this.idAdjective = idAdjective;
    }

    public String getAdjectiveDate() {
        return AdjectiveDate;
    }

    public void setAdjectiveDate(String adjectiveDate) {
        AdjectiveDate = adjectiveDate;
    }

    public Long getOrder() {
        return order;
    }

    public void setOrder(Long order) {
        this.order = order;
    }
}
