package co.com.experian.novedat.core.request;

import java.io.Serializable;

public class ModificationBehaviorVectorDto implements Serializable {

    private Long idModificationBehavVect;
    private Long idModification;
    private Long status;
    private Long sequenceMonth;

    public Long getIdModificationBehavVect() {
        return idModificationBehavVect;
    }

    public void setIdModificationBehavVect(Long idModificationBehavVect) {
        this.idModificationBehavVect = idModificationBehavVect;
    }

    public Long getIdModification() {
        return idModification;
    }

    public void setIdModification(Long idModification) {
        this.idModification = idModification;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    public Long getSequenceMonth() {
        return sequenceMonth;
    }

    public void setSequenceMonth(Long sequenceMonth) {
        this.sequenceMonth = sequenceMonth;
    }
}
