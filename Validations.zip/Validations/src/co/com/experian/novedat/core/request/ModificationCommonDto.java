package co.com.experian.novedat.core.request;

import java.io.Serializable;

public class ModificationCommonDto implements Serializable {

    private Long idModificationCommon;
    private Long idModification;
    private String eventDate;
    private String event;
    private String fillingOffice;
    private String filingCityName;
    private String rating;
    private String stateOfAccountHolder;
    private String currncyType;
    private String accountOpeningDate;
    private String reportDateEvent;
    private String avalaibleBalance;
    private String instllmentsOverdue;

    public Long getIdModificationCommon() {
        return idModificationCommon;
    }

    public void setIdModificationCommon(Long idModificationCommon) {
        this.idModificationCommon = idModificationCommon;
    }

    public Long getIdModification() {
        return idModification;
    }

    public void setIdModification(Long idModification) {
        this.idModification = idModification;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getFillingOffice() {
        return fillingOffice;
    }

    public void setFillingOffice(String fillingOffice) {
        this.fillingOffice = fillingOffice;
    }

    public String getFilingCityName() {
        return filingCityName;
    }

    public void setFilingCityName(String filingCityName) {
        this.filingCityName = filingCityName;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getStateOfAccountHolder() {
        return stateOfAccountHolder;
    }

    public void setStateOfAccountHolder(String stateOfAccountHolder) {
        this.stateOfAccountHolder = stateOfAccountHolder;
    }

    public String getCurrncyType() {
        return currncyType;
    }

    public void setCurrncyType(String currncyType) {
        this.currncyType = currncyType;
    }

    public String getAccountOpeningDate() {
        return accountOpeningDate;
    }

    public void setAccountOpeningDate(String accountOpeningDate) {
        this.accountOpeningDate = accountOpeningDate;
    }

    public String getReportDateEvent() {
        return reportDateEvent;
    }

    public void setReportDateEvent(String reportDateEvent) {
        this.reportDateEvent = reportDateEvent;
    }

    public String getAvalaibleBalance() {
        return avalaibleBalance;
    }

    public void setAvalaibleBalance(String avalaibleBalance) {
        this.avalaibleBalance = avalaibleBalance;
    }

    public String getInstllmentsOverdue() {
        return instllmentsOverdue;
    }

    public void setInstllmentsOverdue(String instllmentsOverdue) {
        this.instllmentsOverdue = instllmentsOverdue;
    }
}
