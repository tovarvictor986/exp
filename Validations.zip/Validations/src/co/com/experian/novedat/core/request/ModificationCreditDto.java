package co.com.experian.novedat.core.request;

import java.io.Serializable;

public class ModificationCreditDto implements Serializable {

    private Long idModificationCommon;
    private Long idModification;
    private String expiryDate;
    private String accountStatus;
    private String typeOfDebtor;
    private String periodicityOfPayments;
    private String freeValue;
    private String initialValue;
    private String debtBalance;
    private String valueBalanceOverdue;
    private String overdueDay;
    private String originOfStatusAccount;
    private String dateOfOriginStatus;
    private String paymentDate;
    private String cardClass;
    private String franchise;
    private String cardStatus;
    private String dateOfCardStatus;
    private String guaranteeType;
    private String paymentType;
    private String typeOfCredit;
    private String dateOfAccountStatus;
    private String totalValueOfChecksReturned;
    private String totalValueOfChecksPaid;
    private String paymentDeadLine;
    private String contractType;
    private String permanenceClause;
    private String permanenceClauseDate;
    private String privateBrandName;
    private String mortgageSubsidy;
    private String mortgageSubsidyDate;
    private String probablyOfDefault;

    public Long getIdModificationCommon() {
        return idModificationCommon;
    }

    public void setIdModificationCommon(Long idModificationCommon) {
        this.idModificationCommon = idModificationCommon;
    }

    public Long getIdModification() {
        return idModification;
    }

    public void setIdModification(Long idModification) {
        this.idModification = idModification;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getAccountStatus() {
        return accountStatus;
    }

    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public String getTypeOfDebtor() {
        return typeOfDebtor;
    }

    public void setTypeOfDebtor(String typeOfDebtor) {
        this.typeOfDebtor = typeOfDebtor;
    }

    public String getPeriodicityOfPayments() {
        return periodicityOfPayments;
    }

    public void setPeriodicityOfPayments(String periodicityOfPayments) {
        this.periodicityOfPayments = periodicityOfPayments;
    }

    public String getFreeValue() {
        return freeValue;
    }

    public void setFreeValue(String freeValue) {
        this.freeValue = freeValue;
    }

    public String getInitialValue() {
        return initialValue;
    }

    public void setInitialValue(String initialValue) {
        this.initialValue = initialValue;
    }

    public String getDebtBalance() {
        return debtBalance;
    }

    public void setDebtBalance(String debtBalance) {
        this.debtBalance = debtBalance;
    }

    public String getValueBalanceOverdue() {
        return valueBalanceOverdue;
    }

    public void setValueBalanceOverdue(String valueBalanceOverdue) {
        this.valueBalanceOverdue = valueBalanceOverdue;
    }

    public String getOverdueDay() {
        return overdueDay;
    }

    public void setOverdueDay(String overdueDay) {
        this.overdueDay = overdueDay;
    }

    public String getOriginOfStatusAccount() {
        return originOfStatusAccount;
    }

    public void setOriginOfStatusAccount(String originOfStatusAccount) {
        this.originOfStatusAccount = originOfStatusAccount;
    }

    public String getDateOfOriginStatus() {
        return dateOfOriginStatus;
    }

    public void setDateOfOriginStatus(String dateOfOriginStatus) {
        this.dateOfOriginStatus = dateOfOriginStatus;
    }

    public String getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(String paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getCardClass() {
        return cardClass;
    }

    public void setCardClass(String cardClass) {
        this.cardClass = cardClass;
    }

    public String getFranchise() {
        return franchise;
    }

    public void setFranchise(String franchise) {
        this.franchise = franchise;
    }

    public String getCardStatus() {
        return cardStatus;
    }

    public void setCardStatus(String cardStatus) {
        this.cardStatus = cardStatus;
    }

    public String getDateOfCardStatus() {
        return dateOfCardStatus;
    }

    public void setDateOfCardStatus(String dateOfCardStatus) {
        this.dateOfCardStatus = dateOfCardStatus;
    }

    public String getGuaranteeType() {
        return guaranteeType;
    }

    public void setGuaranteeType(String guaranteeType) {
        this.guaranteeType = guaranteeType;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public String getTypeOfCredit() {
        return typeOfCredit;
    }

    public void setTypeOfCredit(String typeOfCredit) {
        this.typeOfCredit = typeOfCredit;
    }

    public String getDateOfAccountStatus() {
        return dateOfAccountStatus;
    }

    public void setDateOfAccountStatus(String dateOfAccountStatus) {
        this.dateOfAccountStatus = dateOfAccountStatus;
    }

    public String getTotalValueOfChecksReturned() {
        return totalValueOfChecksReturned;
    }

    public void setTotalValueOfChecksReturned(String totalValueOfChecksReturned) {
        this.totalValueOfChecksReturned = totalValueOfChecksReturned;
    }

    public String getTotalValueOfChecksPaid() {
        return totalValueOfChecksPaid;
    }

    public void setTotalValueOfChecksPaid(String totalValueOfChecksPaid) {
        this.totalValueOfChecksPaid = totalValueOfChecksPaid;
    }

    public String getPaymentDeadLine() {
        return paymentDeadLine;
    }

    public void setPaymentDeadLine(String paymentDeadLine) {
        this.paymentDeadLine = paymentDeadLine;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getPermanenceClause() {
        return permanenceClause;
    }

    public void setPermanenceClause(String permanenceClause) {
        this.permanenceClause = permanenceClause;
    }

    public String getPermanenceClauseDate() {
        return permanenceClauseDate;
    }

    public void setPermanenceClauseDate(String permanenceClauseDate) {
        this.permanenceClauseDate = permanenceClauseDate;
    }

    public String getPrivateBrandName() {
        return privateBrandName;
    }

    public void setPrivateBrandName(String privateBrandName) {
        this.privateBrandName = privateBrandName;
    }

    public String getMortgageSubsidy() {
        return mortgageSubsidy;
    }

    public void setMortgageSubsidy(String mortgageSubsidy) {
        this.mortgageSubsidy = mortgageSubsidy;
    }

    public String getMortgageSubsidyDate() {
        return mortgageSubsidyDate;
    }

    public void setMortgageSubsidyDate(String mortgageSubsidyDate) {
        this.mortgageSubsidyDate = mortgageSubsidyDate;
    }

    public String getProbablyOfDefault() {
        return probablyOfDefault;
    }

    public void setProbablyOfDefault(String probablyOfDefault) {
        this.probablyOfDefault = probablyOfDefault;
    }
}
