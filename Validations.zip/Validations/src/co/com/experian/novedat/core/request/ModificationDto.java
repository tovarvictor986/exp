package co.com.experian.novedat.core.request;

import java.io.Serializable;

public class ModificationDto implements Serializable {

    private Long idModification;
    private Long idModInfoGeneral;
    private String status;
    private String userCreation;
    private String dateCreation;
    private String justificationCode;
    private String justificationCodeAction;
    private String comment;
    private String dateBlock15;
    private String dateBlock23;

    public Long getIdModification() {
        return idModification;
    }

    public void setIdModification(Long idModification) {
        this.idModification = idModification;
    }

    public Long getIdModInfoGeneral() {
        return idModInfoGeneral;
    }

    public void setIdModInfoGeneral(Long idModInfoGeneral) {
        this.idModInfoGeneral = idModInfoGeneral;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getUserCreation() {
        return userCreation;
    }

    public void setUserCreation(String userCreation) {
        this.userCreation = userCreation;
    }

    public String getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(String dateCreation) {
        this.dateCreation = dateCreation;
    }

    public String getJustificationCode() {
        return justificationCode;
    }

    public void setJustificationCode(String justificationCode) {
        this.justificationCode = justificationCode;
    }

    public String getJustificationCodeAction() {
        return justificationCodeAction;
    }

    public void setJustificationCodeAction(String justificationCodeAction) {
        this.justificationCodeAction = justificationCodeAction;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDateBlock15() {
        return dateBlock15;
    }

    public void setDateBlock15(String dateBlock15) {
        this.dateBlock15 = dateBlock15;
    }

    public String getDateBlock23() {
        return dateBlock23;
    }

    public void setDateBlock23(String dateBlock23) {
        this.dateBlock23 = dateBlock23;
    }
}
