package co.com.experian.novedat.core.request;

import java.io.Serializable;

public class ModificationInfoGeneralDto implements Serializable {

    private Long idModInfoGeneral;
    private String caseNumber;
    private String subscriberCode;
    private String subscriberName;
    private String accountNumber;
    private String creditType;
    private String idType;
    private String idNumber;
    private String asReported;
    private String channelCode;
    private String serviceCode;
    private String informationCode;
    private String solutionCode;
    private String auditar;
    private String auditado;
    private String registerNumber;
    private String disputeCode;
    private String blockAutoRegular;
    private String disputeLawCode;
    private String extendCode;
    private String repositionCode;

    public Long getIdModInfoGeneral() {
        return idModInfoGeneral;
    }

    public void setIdModInfoGeneral(Long idModInfoGeneral) {
        this.idModInfoGeneral = idModInfoGeneral;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getSubscriberCode() {
        return subscriberCode;
    }

    public void setSubscriberCode(String subscriberCode) {
        this.subscriberCode = subscriberCode;
    }

    public String getSubscriberName() {
        return subscriberName;
    }

    public void setSubscriberName(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCreditType() {
        return creditType;
    }

    public void setCreditType(String creditType) {
        this.creditType = creditType;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber;
    }

    public String getAsReported() {
        return asReported;
    }

    public void setAsReported(String asReported) {
        this.asReported = asReported;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public void setServiceCode(String serviceCode) {
        this.serviceCode = serviceCode;
    }

    public String getInformationCode() {
        return informationCode;
    }

    public void setInformationCode(String informationCode) {
        this.informationCode = informationCode;
    }

    public String getSolutionCode() {
        return solutionCode;
    }

    public void setSolutionCode(String solutionCode) {
        this.solutionCode = solutionCode;
    }

    public String getAuditar() {
        return auditar;
    }

    public void setAuditar(String auditar) {
        this.auditar = auditar;
    }

    public String getAuditado() {
        return auditado;
    }

    public void setAuditado(String auditado) {
        this.auditado = auditado;
    }

    public String getRegisterNumber() {
        return registerNumber;
    }

    public void setRegisterNumber(String registerNumber) {
        this.registerNumber = registerNumber;
    }

    public String getDisputeCode() {
        return disputeCode;
    }

    public void setDisputeCode(String disputeCode) {
        this.disputeCode = disputeCode;
    }

    public String getBlockAutoRegular() {
        return blockAutoRegular;
    }

    public void setBlockAutoRegular(String blockAutoRegular) {
        this.blockAutoRegular = blockAutoRegular;
    }

    public String getDisputeLawCode() {
        return disputeLawCode;
    }

    public void setDisputeLawCode(String disputeLawCode) {
        this.disputeLawCode = disputeLawCode;
    }

    public String getExtendCode() {
        return extendCode;
    }

    public void setExtendCode(String extendCode) {
        this.extendCode = extendCode;
    }

    public String getRepositionCode() {
        return repositionCode;
    }

    public void setRepositionCode(String repositionCode) {
        this.repositionCode = repositionCode;
    }
}
