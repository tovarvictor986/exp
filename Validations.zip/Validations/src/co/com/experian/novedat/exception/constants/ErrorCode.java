package co.com.experian.novedat.exception.constants;

public class ErrorCode {

    public static final String UNEXPECTED_ERROR = "-1";
    public static final String MOTOR_VALIDATION_ERROR = "100";

}
