package co.com.experian.novedat.exception.constants;

public class ErrorMessage {

    public static final String UNEXPECTED_ERROR = "Error, ha ocurrido un error inesperado";

}
