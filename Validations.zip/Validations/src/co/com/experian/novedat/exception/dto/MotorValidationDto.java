package co.com.experian.novedat.exception.dto;

import java.io.Serializable;
import java.util.List;

import co.com.experian.novedat.bridge.dto.ObligationInfoEnableErrorDto;

public class MotorValidationDto implements Serializable {


    private List<String> errorList;
    private ObligationInfoEnableErrorDto obligInfoEnableErrorDto;

    public List<String> getErrorList() {
        return errorList;
    }

    public void setErrorList(List<String> errorList) {
        this.errorList = errorList;
    }

    public ObligationInfoEnableErrorDto getObligInfoEnableErrorDto() {
        return obligInfoEnableErrorDto;
    }

    public void setObligInfoEnableErrorDto(ObligationInfoEnableErrorDto obligInfoEnableErrorDto) {
        this.obligInfoEnableErrorDto = obligInfoEnableErrorDto;
    }
}

