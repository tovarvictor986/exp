package co.com.experian.novedat.exception.exceptions;

import co.com.experian.novedat.exception.constants.ErrorCode;
import co.com.experian.novedat.exception.dto.MotorValidationDto;

public class MotorValidationException extends NovedatException {

    @Override
    public String getCode() {
        return ErrorCode.MOTOR_VALIDATION_ERROR;
    }

    public MotorValidationException(String message) {
        super(message);
    }

    public MotorValidationException(String message, MotorValidationDto motorValidationDto) {
        super(message, motorValidationDto);
    }

    public MotorValidationException(String message, Throwable cause) {
        super(message, cause);
    }

    public MotorValidationException(Throwable cause) {
        super(cause);
    }
}

