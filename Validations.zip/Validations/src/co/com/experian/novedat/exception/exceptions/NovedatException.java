package co.com.experian.novedat.exception.exceptions;

import co.com.experian.novedat.exception.constants.ErrorCode;
import co.com.experian.novedat.exception.dto.MotorValidationDto;

public class NovedatException extends Exception {

    public String getCode() {
        return ErrorCode.UNEXPECTED_ERROR;
    }

    public MotorValidationDto motorValidationDto;

    public MotorValidationDto getMotorValidationDto() {
        return motorValidationDto;
    }

    public void setMotorValidationDto(MotorValidationDto motorValidationDto) {
        this.motorValidationDto = motorValidationDto;
    }

    public NovedatException() {}

    public NovedatException(String message) { super(message); }
    public NovedatException(String message, MotorValidationDto motorValidationDto) {
        super(message);
        this.motorValidationDto = motorValidationDto;
    }
    public NovedatException(String message, Throwable cause) { super(message, cause); }
    public NovedatException(Throwable cause) { super(cause); }

}
