package co.com.experian.novedat.validations;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.text.Utilities;
import javax.xml.ws.spi.Invoker;

import co.com.experian.novedat.bridge.dto.ObligationInfoDto;
import co.com.experian.novedat.bridge.dto.Rules;
import co.com.experian.novedat.validations.dto.ObjectConditions;
import co.com.experian.novedat.validations.util.Utils;

public class Main {
	
	Utils utilities = new Utils();

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			// TODO Auto-generated method stub
			 ObligationInfoDto objValues = new ObligationInfoDto();
			 ObjectConditions objCond = new ObjectConditions();
			 List<String> listMessages = new ArrayList<>();
			 //System.out.println(listMessages.getClass().getSimpleName());
			// objValues.setAdjective("VICTOR TOVAR");
			// Utils r = new Utils();
			// //System.out.println("XXXX>>>> "+r.extractValue(objValues,"Adjective"));
			// System.out.println("validate Numeric >>  "+r.isNumeric("4444"));
			// // System.out.println("validate date start");
			// System.out.println("validate Date >>  "+r.isThisDateValid("2018/12/02","yyyy/mm/dd"));
			// // System.out.println("validate date end");
//			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/mm/dd");
//			Date date1 = sdf.parse("2018/01/05");
//			Date date2 = sdf.parse("2017/01/05");
			Rules r = new Rules();
			
			 if(r.generalCompare("2028-01-01", "2019-01-01", ">")){
				 System.out.println("NO CUMPLE REGLA");
			 }else{
				 System.out.println("CUMPLE LA REGLA");
			 }
			 
			
		} catch (Exception e) {

		}
	}
	
	

}
