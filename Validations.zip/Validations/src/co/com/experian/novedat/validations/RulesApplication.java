/**
 * Returns an Message  depending of applied rules list on  values.  
 *
 * @param  	A List of  ObjectConditions 
 * @param  	An Object ObligationInfoEnableDto type
 * @return  A menssage depending of validations
 * @author  ....
 */
package co.com.experian.novedat.validations;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.text.Utilities;

import co.com.experian.novedat.bridge.dto.ObligationInfoDto;
import co.com.experian.novedat.bridge.dto.ObligationInfoEnableDto;
import co.com.experian.novedat.bridge.dto.ObligationInfoEnableErrorDto;
import co.com.experian.novedat.exception.dto.MotorValidationDto;
import co.com.experian.novedat.exception.exceptions.MotorValidationException;
import co.com.experian.novedat.validations.dto.ObjectConditions;
import co.com.experian.novedat.validations.util.Utils;

public class RulesApplication {
	Utils utilities = new Utils();
	String formatDate = "yyyy/mm/dd";
	List<String> listMessages = new ArrayList<>();
	String msgError = new String();
	
	MotorValidationDto motorValidationDto = new MotorValidationDto();
	ObligationInfoEnableErrorDto obligationInfoEnableErrorDto = new ObligationInfoEnableErrorDto();
	
	public void appliedRules(ArrayList<ObjectConditions> l,
			ObligationInfoDto objValues) {
		try {
			List<String> list = new ArrayList<String>();
			
			list.add("8");

			for (ObjectConditions obj : l) {
				obj.setValuesList(list);
				String operador = obj.getConOperator();
				String idField1 = obj.getIdField1();
				String idField2 = obj.getIdField2();

				String nameField11 = obj.getFieldName1();
				String nameField12 = obj.getFieldName2();

				String value1 = utilities.extractValue(objValues, nameField11);
				String value2 = utilities.extractValue(objValues, nameField12);

				// validaciones tipo de datos, 1� se validan fechas
				if (utilities.isThisDateValid(value1,formatDate)&&utilities.isThisDateValid(value1,formatDate)) {
					Date date1 = new SimpleDateFormat(formatDate).parse(value1);
					Date date2 = new SimpleDateFormat(formatDate).parse(value2);
					switch (operador) {
					case "<": 
						if (!(date1.before(date2))) {
							msgError = obj.getRulDescription();
							listMessages.add(msgError);
						}
						break;
					case ">":
						if (!(date1.after(date2))) {
							msgError = obj.getRulDescription();
							listMessages.add(msgError);
						}
						break;
					case "=":
						if (!(date2.equals(date1))) {
							msgError = obj.getRulDescription();
							listMessages.add(msgError);
						}
						break;
					}
				}
				
				// validaciones tipo de datos, 2� se validan tipos de datos numericos
				if (utilities.isNumeric(value1)&&utilities.isNumeric(value1)) {
					Integer num1 = Integer.parseInt(value1);
					Integer num2 = Integer.parseInt(value2);
					switch (operador) {
					case "<": 
						if (!(num1<num2)) {
							msgError = obj.getRulDescription();
							listMessages.add(msgError);
						}
						break;
					case ">":
						if (!(num1>num2)) {
							msgError = obj.getRulDescription();
							listMessages.add(msgError);
						}
						break;
					case "=":
						if (num1!=num2) {
							msgError = obj.getRulDescription();
							listMessages.add(msgError);
						}
						break;						
					}
				}
				
			}
			
			motorValidationDto.setErrorList(listMessages);
			throw new MotorValidationException("EJECUTO MOTOR DE VALIDACIONES", motorValidationDto);		
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	

}
