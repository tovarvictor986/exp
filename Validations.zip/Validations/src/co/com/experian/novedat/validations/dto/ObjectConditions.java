/**
 * Class with the values for rules application  
 *
 * @param  	
 * @param  	
 * @return  
 * @author  ....
 */
package co.com.experian.novedat.validations.dto;

import java.util.List;

public class ObjectConditions {
	
	private String idRuleCondition;
	private String idAccountType;
	private String accountTypeName;
	private String idRule;
	private String rulDescription;
	private String rulIsActive;

	private String idField1;
	private String fieldName1;

	private String idField2;
	private String fieldName2;
	
	private String idCondition;
	private String conOperator;
	
	//campos nuevos
	private String conIsConstant;
	private String conIsComposite;
	private String conIsValueList;	
	private String conValue;
	
	private List<String> valuesList;
	
	
	
	public ObjectConditions() {
		//super();
	}

	public ObjectConditions(String idRuleCondition, String idAccountType,
			String accountTypeName, String idRule, String rulDescription,
			String rulIsActive, String idField1, String fieldName1,
			String idField2, String fieldName2, String idCondition,
			String conOperator, String conIsConstant, String conIsComposite, String conIsValueList, String conValue) {
		//super();
		this.idRuleCondition = idRuleCondition;
		this.idAccountType = idAccountType;
		this.accountTypeName = accountTypeName;
		this.idRule = idRule;
		this.rulDescription = rulDescription;
		this.rulIsActive = rulIsActive;
		this.idField1 = idField1;
		this.fieldName1 = fieldName1;
		this.idField2 = idField2;
		this.fieldName2 = fieldName2;
		this.idCondition = idCondition;
		this.conOperator = conOperator;
		this.conIsConstant = conIsConstant;
		this.conIsComposite = conIsComposite;
		this.conIsValueList = conIsValueList;
		this.conValue = conValue;
	}
	
	public String getIdRuleCondition() {
		return idRuleCondition;
	}
	public void setIdRuleCondition(String idRuleCondition) {
		this.idRuleCondition = idRuleCondition;
	}
	public String getIdAccountType() {
		return idAccountType;
	}
	public void setIdAccountType(String idAccountType) {
		this.idAccountType = idAccountType;
	}
	public String getAccountTypeName() {
		return accountTypeName;
	}
	public void setAccountTypeName(String accountTypeName) {
		this.accountTypeName = accountTypeName;
	}
	public String getIdRule() {
		return idRule;
	}
	public void setIdRule(String idRule) {
		this.idRule = idRule;
	}
	public String getRulDescription() {
		return rulDescription;
	}
	public void setRulDescription(String rulDescription) {
		this.rulDescription = rulDescription;
	}
	public String getRulIsActive() {
		return rulIsActive;
	}
	public void setRulIsActive(String rulIsActive) {
		this.rulIsActive = rulIsActive;
	}
	public String getIdField1() {
		return idField1;
	}
	public void setIdField1(String idField1) {
		this.idField1 = idField1;
	}
	public String getFieldName1() {
		return fieldName1;
	}
	public void setFieldName1(String fieldName1) {
		this.fieldName1 = fieldName1;
	}
	public String getIdField2() {
		return idField2;
	}
	public void setIdField2(String idField2) {
		this.idField2 = idField2;
	}
	public String getFieldName2() {
		return fieldName2;
	}
	public void setFieldName2(String fieldName2) {
		this.fieldName2 = fieldName2;
	}
	public String getIdCondition() {
		return idCondition;
	}
	public void setIdCondition(String idCondition) {
		this.idCondition = idCondition;
	}
	public String getConOperator() {
		return conOperator;
	}
	public void setConOperator(String conOperator) {
		this.conOperator = conOperator;
	}

	public List<String> getValuesList() {
		return valuesList;
	}

	public void setValuesList(List<String> valuesList) {
		this.valuesList = valuesList;
	}

	public String getConIsConstant() {
		return conIsConstant;
	}

	public void setConIsConstant(String conIsConstant) {
		this.conIsConstant = conIsConstant;
	}

	public String getConIsComposite() {
		return conIsComposite;
	}

	public void setConIsComposite(String conIsComposite) {
		this.conIsComposite = conIsComposite;
	}

	public String getConIsValueList() {
		return conIsValueList;
	}

	public void setConIsValueList(String conIsValueList) {
		this.conIsValueList = conIsValueList;
	}

	public String getConValue() {
		return conValue;
	}

	public void setConValue(String conValue) {
		this.conValue = conValue;
	}

}
