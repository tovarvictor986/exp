package co.com.experian.novedat.validations.util;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import co.com.experian.novedat.bridge.dto.ObligationInfoDto;

public class Utils {

	// validacion de fechas
	public boolean isThisDateValid(String dateToValidate, String dateFromat) {
		try {
			if (dateToValidate == null) {
				return false;
			}
			SimpleDateFormat sdf = new SimpleDateFormat(dateFromat);
			sdf.setLenient(false);
			// if not valid, it will throw ParseException
			Date date = sdf.parse(dateToValidate);
			//System.out.println(date);

		} catch (ParseException e) {

			e.printStackTrace();
			return false;
		}

		return true;
	}

	// extrae el valor de un atributo de un objeto
	public String extractValue(ObligationInfoDto objV, String met) {
		String value = "";
		// Method meth = null;
		try {
			String s1 = "get";
			String method = s1 + met;

			Method[] listM = objV.getClass().getMethods();

			Method listM2 = objV.getClass().getMethod(method);
			// System.out.println("verdad >> "+listM2.invoke(objV));
			value = listM2.invoke(objV).toString();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return value;
	}

	// validacion si un string es un n�mero
	public boolean isNumeric(String str) {
		try {
			double d = Double.parseDouble(str);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	
	//Validar tipo de dato, recibe: valor1, valor2, operador, tipoDato
	public void validateTypeData(String v1, String v2, String op, String tipoDato){
		if(tipoDato.equals("")){
			
		}
	}

}
